import argparse
import copy
import io
import json
import logging
import secrets
import subprocess
import sys
import threading
import uuid
import webbrowser
from pathlib import Path
from urllib.parse import urlsplit
from flask import Flask, jsonify, request, send_file, send_from_directory
from PIL import Image, ImageOps
from werkzeug.serving import make_server
from .engine import analyze
from .storage import atomic_json, validate, export_project


def create_app(home=None):
    app = Flask(__name__, static_folder='static')
    app.config['MAX_CONTENT_LENGTH'] = 20 * 1024 * 1024
    home = Path(home or Path.home() / 'Library/Application Support/PyroFamilySorter').expanduser().resolve()
    home.mkdir(parents=True, exist_ok=True)
    token = secrets.token_urlsafe(32)
    state = {'project': None, 'path': None, 'job': {'running': False, 'done': 0, 'total': 0, 'message': ''}}
    lock = threading.RLock()
    cancel = threading.Event()
    app.extensions['sorter'] = {'state': state, 'token': token, 'lock': lock}

    @app.before_request
    def protect():
        if request.host.split(':')[0] not in ('127.0.0.1', 'localhost'):
            return jsonify(error='Недопустимый Host'), 403
        origin = request.headers.get('Origin')
        if origin and origin != request.host_url.rstrip('/'):
            return jsonify(error='Внешний Origin запрещён'), 403
        if request.path.startswith(('/api/', '/photo/')):
            supplied = request.headers.get('X-Session-Token') or request.args.get('token', '')
            if not secrets.compare_digest(supplied, token):
                return jsonify(error='Обновите страницу: неверный токен сессии.'), 403

    @app.after_request
    def headers(response):
        response.headers['Cache-Control'] = 'no-store'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['Content-Security-Policy'] = "default-src 'self'; img-src 'self' blob:; style-src 'self'; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'"
        return response

    @app.errorhandler(Exception)
    def error(e):
        from werkzeug.exceptions import HTTPException
        if isinstance(e, HTTPException):
            return jsonify(error=e.description), e.code
        logging.exception('Ошибка запроса')
        return jsonify(error=str(e)), 400

    @app.get('/')
    def index():
        return Path(app.static_folder, 'index.html').read_text().replace('__TOKEN__', token)

    @app.get('/api/state')
    def get_state():
        with lock:
            return jsonify(project=state['project'], path=str(state['path'] or ''), job=state['job'], platform=sys.platform)

    @app.post('/api/pick')
    def pick():
        if sys.platform != 'darwin':
            raise ValueError('На этой ОС вставьте путь в поле. Нативный выбор доступен на Mac.')
        kind = request.json.get('kind')
        script = 'POSIX path of (choose folder with prompt "Выберите папку")' if kind == 'folder' else 'POSIX path of (choose file with prompt "Выберите файл")'
        proc = subprocess.run(['osascript', '-e', script], capture_output=True, text=True, timeout=180)
        if proc.returncode:
            return jsonify(path='', cancelled=True)
        return jsonify(path=proc.stdout.strip())

    @app.post('/api/analyze')
    def start():
        args = request.json
        source = Path(args['source']).expanduser().resolve()
        output = Path(args['project_dir']).expanduser().resolve()
        if output == source or source in output.parents or home == source or source in home.parents:
            raise ValueError('Проект и кеш должны находиться вне папки фотографий.')
        catalog = args.get('catalog') or str(Path(__file__).parent.parent / 'catalog.csv')
        with lock:
            if state['job']['running']:
                raise ValueError('Дождитесь завершения текущего анализа.')
            output.mkdir(parents=True, exist_ok=True)
            project_path = output / ('project-' + uuid.uuid4().hex[:12] + '.json')
            cancel.clear()
            state['job'] = {'running': True, 'done': 0, 'total': 0, 'message': 'Подготовка', 'error': None}
        def progress(done, total, message):
            with lock:
                state['job'].update(done=done, total=total, message=message)
        def work():
            try:
                project = analyze(source, catalog, home / 'cache', progress, cancel.is_set, args.get('ocr', True), args.get('weights') or None, args.get('prior') or None)
                validate(project)
                atomic_json(project_path, project)
                with lock:
                    state.update(project=project, path=project_path)
            except Exception as e:
                logging.exception('Ошибка анализа')
                with lock:
                    state['job'].update(error=str(e), message=str(e))
            finally:
                with lock:
                    state['job']['running'] = False
        threading.Thread(target=work, daemon=True).start()
        return jsonify(started=True)

    @app.post('/api/cancel')
    def stop():
        cancel.set()
        return jsonify(message='Отмена после обработки текущего файла.')

    @app.post('/api/open')
    def open_project():
        path = Path(request.json['path']).expanduser().resolve()
        with lock:
            if state['job']['running']:
                raise ValueError('Сначала завершите или отмените анализ.')
            project = validate(json.loads(path.read_text(encoding='utf-8')))
            state.update(project=project, path=path)
        return jsonify(project=project, path=str(path))

    @app.post('/api/save')
    def save():
        body = request.json
        with lock:
            if state['job']['running']:
                raise ValueError('Во время анализа редактирование приостановлено.')
            original = state['project']
            if not original or body.get('revision') != original['revision']:
                raise ValueError('Проект изменён в другой вкладке. Обновите страницу.')
            project = copy.deepcopy(original)
            groups = body['groups']
            old = {g['id']: g for g in original['groups']}
            allowed = ('id', 'photo_ids', 'name', 'sku', 'status', 'confidence', 'reasons', 'needs_review')
            project['groups'] = []
            for g in groups:
                group = {k: g.get(k) for k in allowed}
                if not re_valid(group):
                    raise ValueError('Некорректное имя, артикул или ID группы.')
                before = old.get(group['id'])
                changed = not before or any(before[k] != group[k] for k in ('photo_ids', 'name', 'sku'))
                if changed:
                    group.update(status='pending', confidence=.5, needs_review=True, reasons=['Группа изменена вручную; подтвердите после проверки'])
                else:
                    group['confidence'] = before['confidence']
                    group['reasons'] = before['reasons']
                    group['needs_review'] = group['status'] != 'approved'
                project['groups'].append(group)
            validate(project)
            project['revision'] += 1
            atomic_json(state['path'].with_suffix('.backup.json'), original)
            atomic_json(state['path'], project)
            state['project'] = project
        return jsonify(project=project)

    @app.post('/api/export')
    def export():
        with lock:
            if state['job']['running'] or not state['project']:
                raise ValueError('Сначала откройте готовый проект.')
            return jsonify(export_project(state['project'], request.json['destination']))

    @app.get('/photo/<pid>')
    def photo(pid):
        with lock:
            p = next((p for p in (state['project'] or {}).get('photos', []) if p['id'] == pid), None)
        if not p:
            return jsonify(error='Фото не найдено'), 404
        if request.args.get('size') != 'full' and p.get('thumbnail') and Path(p['thumbnail']).is_file():
            return send_file(p['thumbnail'], mimetype='image/jpeg')
        with Image.open(p['source']) as im:
            im = ImageOps.exif_transpose(im).convert('RGB')
            im.thumbnail((2400, 2400) if request.args.get('size') == 'full' else (420, 320))
            stream = io.BytesIO()
            im.save(stream, format='JPEG', quality=90)
        stream.seek(0)
        return send_file(stream, mimetype='image/jpeg')
    return app


def re_valid(g):
    import re
    return isinstance(g['id'], str) and re.fullmatch(r'[a-zA-Z0-9_-]{1,80}', g['id']) and all(isinstance(g[k], str) and len(g[k]) <= 250 for k in ('name', 'sku'))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--home', type=Path)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    home = args.home or Path.home() / 'Library/Application Support/PyroFamilySorter'
    home.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(filename=home/'sorter.log', level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
    app = create_app(home)
    server = make_server('127.0.0.1', args.port, app, threaded=True)
    url = f'http://127.0.0.1:{server.server_port}/'
    print('Pyro Family Photo Sorter:', url, flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
