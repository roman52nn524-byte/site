import copy
import unittest
from unittest.mock import patch
from pyro_sorter.cloud import cluster, main_title
from pyro_sorter.catalog import Catalog


class CloudTests(unittest.TestCase):
    def rows(self):
        return [dict(id=str(i),source=f'/folder{i%2}/IMG_{1000+i*100}.jpg',sha256=str(i),
                     filename=f'IMG_{i}.jpg',match=Catalog().identify(''),features={},text_tokens=[]) for i in range(5)]

    def test_noncontiguous_confirmed_groups(self):
        rows=self.rows();refs={'0':{'group':'A'},'4':{'group':'A'},'1':{'group':'B'},'2':{'group':'C'}}
        with patch('pyro_sorter.cloud.learned_affinity',return_value=.2):groups,_=cluster(rows,reference=refs)
        self.assertIn(['0','4'],[g['photo_ids'] for g in groups])
        self.assertEqual(len(groups),4)

    def test_global_visual_matching_without_references(self):
        rows=self.rows()
        def score(a,b,_):return .95 if {a['id'],b['id']}=={'0','4'} else .1
        with patch('pyro_sorter.cloud.learned_affinity',side_effect=score):groups,_=cluster(rows,reference={})
        self.assertIn(['0','4'],[g['photo_ids'] for g in groups])

    def test_different_titles_override_similar_design(self):
        rows=self.rows()[:2];rows[0]['main_title']='НОВАТОР';rows[1]['main_title']='ХАОС'
        with patch('pyro_sorter.cloud.learned_affinity',return_value=.99):groups,_=cluster(rows,reference={})
        self.assertEqual(len(groups),2)

    def test_unknown_cannot_bridge_distinct_confirmed_products(self):
        rows=self.rows()[:3];refs={'0':{'group':'A'},'2':{'group':'B'}}
        with patch('pyro_sorter.cloud.learned_affinity',return_value=.99):groups,_=cluster(rows,reference=refs)
        self.assertFalse(any('0' in g['photo_ids'] and '2' in g['photo_ids'] for g in groups))

    def test_user_correction_overrides_reference(self):
        rows=self.rows()[:2];refs={'0':{'group':'A'},'1':{'group':'A'}}
        groups,_=cluster(rows,reference=refs,corrections={'0:1':{'y':0}})
        self.assertEqual(len(groups),2)

    def test_rename_does_not_change_references(self):
        rows=self.rows()[:2];refs={'0':{'group':'A'},'1':{'group':'A'}}
        rows[0]['filename']='other.jpg';rows[0]['source']='/different/new.jpg'
        groups,_=cluster(rows,reference=refs)
        self.assertEqual(len(groups),1)

    def test_title_filters_background_and_generic_words(self):
        lines=[{'text':'ХАОС','confidence':.95,'box':[.3,.3,.4,.1]},
               {'text':'РУБИН','confidence':.99,'box':[.85,.8,.1,.05]}]
        self.assertEqual(main_title(lines),'ХАОС')
        self.assertEqual(main_title([{'text':'ФЕЙЕРВЕРК ШОУ','confidence':.95,'box':[.3,.3,.4,.1]}]),'')
        self.assertEqual(main_title([{'text':'ХАОС','confidence':.95}]),'')

    def test_cancel_and_errors(self):
        with self.assertRaises(InterruptedError):cluster(self.rows(),reference={},cancel=lambda:True)
        rows=self.rows()[:2];rows[0]['error']='broken'
        groups,_=cluster(rows,reference={'0':{'group':'A'},'1':{'group':'A'}})
        self.assertEqual(len(groups),2)


if __name__=='__main__':unittest.main()
