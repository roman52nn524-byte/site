'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const token=$('meta[name="session-token"]').content;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let project=null,projectPath='',dirty=false,history=[],selectedPhotos=new Set(),selectedGroups=new Set(),polling=false;
let reviewData={revision:null,questions:[],failures:{}},reviewIndex=0,reviewMode=false;
async function api(path,body){const res=await fetch('/api/'+path,{method:body===undefined?'GET':'POST',headers:{'X-Session-Token':token,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});const r=await res.json();if(!res.ok)throw Error(r.error||'Ошибка запроса');return r}
function notice(t){$('#notice').textContent=t}
function checkpoint(){history.push(structuredClone(project.groups));if(history.length>20)history.shift();dirty=true}
function invalidate(g){g.status='pending';g.needs_review=true;g.confidence=.5;g.reasons=['Изменено вручную — проверьте и подтвердите'];}
function photoURL(id,full=false){return '/photo/'+encodeURIComponent(id)+'?token='+encodeURIComponent(token)+(full?'&size=full':'')}
function render(){if(!project)return;$('#workspace').hidden=false;$('#project-path').textContent=projectPath;const approved=project.groups.filter(g=>g.status==='approved').length;$('#counts').textContent=`${project.photos.length} фото · ${project.groups.length} групп · ${approved} подтверждено${dirty?' · есть правки':''}`;$('#warnings').textContent=project.warnings.join(' · ');const filter=$('#filter').value;
$('#groups').innerHTML=project.groups.filter(g=>filter==='all'||(filter==='review'?g.status==='pending':g.status===filter)).map(g=>{const photos=g.photo_ids.map(id=>project.photos.find(p=>p.id===id));return `<section class="group ${g.status}" data-gid="${g.id}"><div class="group-head"><label><input type="checkbox" class="group-select" data-gid="${g.id}" ${selectedGroups.has(g.id)?'checked':''}> ${g.photo_ids.length} фото</label><input class="group-name" data-gid="${g.id}" value="${esc(g.name)}" placeholder="Название / Неопознанные" aria-label="Название группы"><input class="group-sku sku" data-gid="${g.id}" value="${esc(g.sku)}" placeholder="Артикул" aria-label="Артикул группы"><span class="confidence">Confidence ${Math.round(g.confidence*100)} / 100</span><button data-approve="${g.id}">${g.status==='approved'?'✓ Подтверждено':'Подтвердить'}</button><button data-reject="${g.id}">${g.status==='rejected'?'Вернуть на проверку':'Отклонить'}</button></div><p class="reason">${esc(g.reasons.join(' · '))}</p><div class="photos">${photos.map(p=>`<article class="photo ${selectedPhotos.has(p.id)?'selected':''}" draggable="true" data-pid="${p.id}">${p.error?'<p class="error">Ошибка чтения файла</p>':`<img loading="lazy" draggable="true" src="${photoURL(p.id)}" alt="${esc(p.filename)}" data-view="${p.id}">`}<label><input class="photo-select" type="checkbox" data-pid="${p.id}" ${selectedPhotos.has(p.id)?'checked':''}>${esc(p.filename)}</label><span class="badge">${esc(p.match.method)} ${esc(p.match.sku||'')}${p.duplicate_of?' · точный дубликат':''}</span>${p.error||p.ocr_error?`<div class="error">${esc(p.error||p.ocr_error)}</div>`:''}<details><summary>OCR и подсказки</summary>${esc(p.ocr_text||'Текст не распознан')}<hr>${esc((p.match.candidates||[]).map(c=>c.name+' — '+c.sku).join('\n'))}</details></article>`).join('')}</div></section>`}).join('');$('#undo').disabled=!history.length;
}
async function save(){if(!project)return;$('#workspace').inert=true;try{const r=await api('save',{revision:project.revision,groups:project.groups});project=r.project;dirty=false;reviewData={revision:null,questions:[],failures:{}};render();renderReview();if(r.learning)renderLearning(r.learning);notice('Проект сохранён. Исправления записаны для обучения. Изменённые группы требуют отдельного подтверждения.')}finally{$('#workspace').inert=false}}
async function refresh(){const s=await api('state');renderLearning(s.learning);$('#train-model').disabled=s.job.running;$('#rollback-model').disabled=s.job.running||!s.learning.can_rollback;$('#open').disabled=s.job.running;reviewData=s.review;renderReview();$('#progress').max=s.job.total||1;$('#progress').value=s.job.done;$('#job').textContent=s.job.message||'';$('#start').disabled=s.job.running;$('#cancel').hidden=!s.job.running;$('#workspace').inert=s.job.running;if(s.job.running){setTimeout(()=>refresh().catch(e=>{polling=false;notice(e.message)}),800)}else{polling=false;if(s.project&&!dirty){project=s.project;projectPath=s.path;render();renderReview()}if(s.job.error)notice(s.job.error)}}
async function picked(kind){return (await api('pick',{kind})).path}
$$('[data-pick]').forEach(b=>b.addEventListener('click',()=>action(async()=>{const path=await picked(b.dataset.kind);if(path)$('#'+b.dataset.pick).value=path})));
async function action(fn){try{await fn()}catch(e){notice(e.message)}}
$('#start').onclick=()=>action(async()=>{if(dirty&&!confirm('Есть несохранённые правки. Запустить новый анализ без их сохранения?'))return;if(!$('#source').value||!$('#project_dir').value)throw Error('Укажите папку фото и отдельную папку проектов.');const args=Object.fromEntries(['source','catalog','project_dir','prior','weights'].map(id=>[id,$('#'+id).value.trim()]));args.mode=$('#mode').value;args.ocr=$('#ocr').checked;await api('analyze',args);dirty=false;history=[];selectedGroups.clear();selectedPhotos.clear();notice('Анализ идёт в фоне. Предыдущий проект не перезаписывается.');polling=true;await refresh()});
$('#cancel').onclick=()=>action(async()=>notice((await api('cancel',{})).message));
$('#open').onclick=()=>action(async()=>{if(dirty&&!confirm('Открыть другой проект без сохранения правок?'))return;let path=$('#open-path').value.trim();if(!path)path=await picked('file');if(!path)return;const r=await api('open',{path});project=r.project;projectPath=r.path;dirty=false;history=[];selectedGroups.clear();selectedPhotos.clear();reviewData={revision:null,questions:[],failures:{}};reviewIndex=0;render();renderReview();notice('Проект открыт.')});
$('#filter').onchange=render;$('#save').onclick=()=>action(save);
$('#undo').onclick=()=>{if(history.length){project.groups=history.pop();dirty=true;selectedPhotos.clear();selectedGroups.clear();render()}};
$('#merge').onclick=()=>action(async()=>{const groups=project.groups.filter(g=>selectedGroups.has(g.id));if(groups.length<2)throw Error('Выберите не менее двух групп.');if(!confirm('Объединить выбранные группы? Название и артикул останутся от первой; подтверждение будет сброшено.'))return;checkpoint();const first=groups[0];first.photo_ids=project.photos.filter(p=>groups.some(g=>g.photo_ids.includes(p.id))).map(p=>p.id);invalidate(first);project.groups=project.groups.filter(g=>!selectedGroups.has(g.id)||g===first);selectedGroups.clear();render()});
$('#split').onclick=()=>action(async()=>{if(!selectedPhotos.size)throw Error('Выберите фотографии для новой группы.');checkpoint();const ids=project.photos.filter(p=>selectedPhotos.has(p.id)).map(p=>p.id);for(const g of project.groups){if(g.photo_ids.some(id=>selectedPhotos.has(id))){g.photo_ids=g.photo_ids.filter(id=>!selectedPhotos.has(id));invalidate(g)}}project.groups=project.groups.filter(g=>g.photo_ids.length);project.groups.push({id:crypto.randomUUID().replaceAll('-','').slice(0,12),photo_ids:ids,name:'',sku:'',status:'pending',confidence:.5,reasons:['Разделено вручную'],needs_review:true});selectedPhotos.clear();render()});
$('#groups').addEventListener('change',e=>{const t=e.target;if(t.classList.contains('group-select')){t.checked?selectedGroups.add(t.dataset.gid):selectedGroups.delete(t.dataset.gid);return}if(t.classList.contains('photo-select')){t.checked?selectedPhotos.add(t.dataset.pid):selectedPhotos.delete(t.dataset.pid);t.closest('.photo').classList.toggle('selected',t.checked);return}if(t.classList.contains('group-name')||t.classList.contains('group-sku')){checkpoint();const g=project.groups.find(g=>g.id===t.dataset.gid);g[t.classList.contains('group-name')?'name':'sku']=t.value.trim();invalidate(g);render()}});
$('#groups').addEventListener('click',e=>action(async()=>{const a=e.target.closest('[data-approve]'),r=e.target.closest('[data-reject]'),v=e.target.closest('[data-view]');if(a){const g=project.groups.find(g=>g.id===a.dataset.approve);const photos=project.photos.filter(p=>g.photo_ids.includes(p.id));if(photos.some(p=>p.error))throw Error('В группе есть повреждённые фото. Отделите их и отклоните.');const keys=new Set(photos.filter(p=>p.match.strong).map(p=>p.match.key));if(keys.size>1&&!confirm('В группе разные распознанные артикулы. Вы проверили, что это один товар?'))return;checkpoint();g.status='approved';g.needs_review=false;render()}if(r){checkpoint();const g=project.groups.find(g=>g.id===r.dataset.reject);g.status=g.status==='rejected'?'pending':'rejected';render()}if(v){const p=project.photos.find(p=>p.id===v.dataset.view);$('#large-photo').src=photoURL(p.id,true);$('#photo-info').textContent=p.source;$('#viewer').showModal()}}));
$('#groups').addEventListener('dragstart',e=>{const p=e.target.closest('[data-pid]');if(p){e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',p.dataset.pid)}});
$('#groups').addEventListener('dragover',e=>{const g=e.target.closest('.group');if(g){e.preventDefault();g.classList.add('drop')}});
$('#groups').addEventListener('dragleave',e=>e.target.closest('.group')?.classList.remove('drop'));
$('#groups').addEventListener('drop',e=>{const target=e.target.closest('.group');if(!target)return;e.preventDefault();const id=e.dataTransfer.getData('text/plain');const from=project.groups.find(g=>g.photo_ids.includes(id)),to=project.groups.find(g=>g.id===target.dataset.gid);if(!from||!to||from===to){target.classList.remove('drop');return}checkpoint();from.photo_ids=from.photo_ids.filter(p=>p!==id);to.photo_ids.push(id);invalidate(from);invalidate(to);project.groups=project.groups.filter(g=>g.photo_ids.length);render()});
$('#close-viewer').onclick=()=>$('#viewer').close();$('#viewer').addEventListener('close',()=>$('#large-photo').removeAttribute('src'));
$('#export').onclick=()=>action(async()=>{if(dirty)await save();const destination=$('#destination').value.trim();if(!destination)throw Error('Укажите папку результата.');const r=await api('export',{destination});notice(`Экспорт завершён: скопировано ${r.copied}, уже существовало ${r.skipped}.\n${r.directory}`)});
window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue=''}});action(refresh);

$('#export-auto').onclick=()=>action(async()=>{
if(!project)return;
const destination=$('#destination').value.trim();
if(!destination)throw Error('Укажите папку результата вне исходников.');
if(dirty)await save();
checkpoint();
let skipped=0;
for(const g of project.groups){
 const photos=project.photos.filter(p=>g.photo_ids.includes(p.id));
 const keys=new Set(photos.filter(p=>p.match.strong).map(p=>p.match.key));
 if(g.status==='rejected'||photos.some(p=>p.error||p.match.conflict)||keys.size>1){skipped++;g.status=g.status==='rejected'?'rejected':'pending';continue;}
 g.status='approved';g.needs_review=false;
}
await save();
const r=await api('export',{destination});
notice(`Готово: скопировано ${r.copied} фото, уже существовало ${r.skipped}. Пропущено групп: ${skipped}. Оригиналы сохранены.\n${r.directory}`);
});

function renderLearning(info){
 if(!info)return;
 $('#learning-status').textContent=`Модель: ${info.active}. Примеров из исправлений: ${info.examples}. Противоречивых пар пропущено: ${info.conflicts}.`;
 $('#rollback-model').disabled=!info.can_rollback;
 const r=info.report;
 $('#learning-report').innerHTML=r?`<p><b>${esc(r.message)}</b></p>${r.old?`<table><thead><tr><th>На проверочных парах</th><th>Прежняя</th><th>Новая</th></tr></thead><tbody><tr><td>Ошибки</td><td>${r.old.errors} из ${r.old.pairs}</td><td>${r.new.errors} из ${r.new.pairs}</td></tr><tr><td>Ошибка оценки сходства (меньше лучше)</td><td>${r.old.loss.toFixed(3)}</td><td>${r.new.loss.toFixed(3)}</td></tr></tbody></table><p>Обучающих пар: ${r.training_pairs}; проверочных: ${r.validation_pairs}. Использовано ваших примеров: ${r.feedback_used}. Недоступных пар пропущено: ${r.missing}.</p><small>${esc(r.caveat)}</small>`:''}`:'';
}
function setReview(on){reviewMode=on;$('#review-panel').hidden=!on;$('#groups').hidden=on;$('#show-all').setAttribute('aria-pressed',String(!on));$('#show-review').setAttribute('aria-pressed',String(on));renderReview()}
function renderReview(){
 if(!project||!reviewMode)return;
 const stale=dirty||reviewData.revision!==project.revision;
 if(stale){$('#review-card').innerHTML='';$('#review-status').textContent='Нажмите «Найти спорные места». Несохранённые правки будут сохранены.';return}
 const questions=reviewData.questions||[];
 if(reviewIndex>=questions.length)reviewIndex=0;
 const skipped=Object.keys(reviewData.failures||{}).length;
 if(!questions.length){$('#review-status').textContent=`Очередь пуста. Спорных мест по текущим признакам не найдено или все ответы уже сохранены. Пропущено недоступных фото: ${skipped}.`;$('#review-card').innerHTML='';return}
 const q=questions[reviewIndex],photo=project.photos.find(p=>p.id===q.photo_id);
 $('#review-status').textContent=`Спорное фото ${reviewIndex+1} из ${questions.length}. ${q.reason}. Недоступных фото: ${skipped}.`;
 const choice=(gid,score,current)=>{const g=project.groups.find(g=>g.id===gid);const position=project.groups.indexOf(g)+1;
 const ids=g.photo_ids.filter(id=>id!==q.photo_id);const representatives=ids.length<=6?ids:Array.from({length:6},(_,i)=>ids[Math.round(i*(ids.length-1)/5)]);
 return `<article class="review-choice"><h3>${esc(g.name||'Товар № '+position)} ${esc(g.sku)}</h3><p>${current?'Текущая группа':'Соседняя группа'} · ${g.photo_ids.length} фото · сходство ${Math.round(score*100)}/100</p><div class="review-thumbs">${representatives.map(id=>`<img src="${photoURL(id)}" data-review-view="${id}" alt="Фото группы">`).join('')||'<p>Других снимков пока нет</p>'}</div><button class="primary" data-review-target="${gid}">${current?'Оставить здесь':'Отнести сюда'}</button></article>`};
 $('#review-card').innerHTML=`<div class="review-focus"><img src="${photoURL(photo.id,true)}" data-review-view="${photo.id}" alt="Спорная фотография"><b>${esc(photo.filename)}</b></div><div class="review-choices">${choice(q.current,q.own_score,true)}${choice(q.alternative,q.alternative_score,false)}</div><p class="muted">Сходство — оценка модели, не вероятность правильного ответа. ${project.grouping_mode==='cloud'?'В режиме «Облако» проверяются все группы.':'Проверяются соседние группы по порядку съёмки.'}</p><button id="skip-review">Отложить, показать следующую</button>`;
 $('#skip-review').onclick=()=>{reviewIndex=(reviewIndex+1)%questions.length;renderReview()};
}
async function buildReview(){if(dirty)await save();reviewIndex=0;await api('review/build',{});await refresh()}
$('#show-all').onclick=()=>setReview(false);
$('#show-review').onclick=()=>{setReview(true);if(!dirty&&reviewData.revision!==project.revision)action(buildReview)};
$('#build-review').onclick=()=>action(buildReview);
$('#review-card').onclick=e=>action(async()=>{
 const view=e.target.closest('[data-review-view]');if(view){$('#large-photo').src=photoURL(view.dataset.reviewView,true);$('#photo-info').textContent=project.photos.find(p=>p.id===view.dataset.reviewView).source;$('#viewer').showModal();return}
 const button=e.target.closest('[data-review-target]');if(!button)return;
 const q=reviewData.questions[reviewIndex];$('#review-panel').inert=true;
 try{const r=await api('review/decide',{revision:project.revision,photo_id:q.photo_id,target:button.dataset.reviewTarget});project=r.project;reviewData=r.review;dirty=false;history=[];reviewIndex=0;render();renderReview();renderLearning(r.learning);$('#undo-review').disabled=false;notice('Ответ сохранён и добавлен в примеры обучения.');if(reviewData.revision===null)await buildReview()}finally{$('#review-panel').inert=false}
});
$('#undo-review').onclick=()=>action(async()=>{const r=await api('review/undo',{revision:project.revision});project=r.project;reviewData=r.review;dirty=false;history=[];render();renderReview();renderLearning(r.learning);$('#undo-review').disabled=true;notice('Последний ответ отменён, примеры обучения обновлены.');await buildReview()});
$('#train-model').onclick=()=>action(async()=>{if(dirty)await save();await api('learning/train',{});await refresh()});
$('#rollback-model').onclick=()=>action(async()=>{const r=await api('learning/rollback',{});renderLearning(r.learning);notice('Предыдущая модель восстановлена. Она применяется при новом анализе.');await refresh()});
