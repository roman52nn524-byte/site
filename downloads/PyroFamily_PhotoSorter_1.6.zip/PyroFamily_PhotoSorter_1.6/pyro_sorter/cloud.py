"""Whole-folder clustering with explicit user constraints and OCR title conflicts."""
import json
import re
import uuid
from pathlib import Path
from .pair_model import load_model
from .smart import learned_affinity


def references():
    return json.loads(Path(__file__).with_name('cloud_references.json').read_text())


def main_title(lines):
    """Use only a large central OCR line; background text is not product identity."""
    stop={'САЛЮТ','ФЕЙЕРВЕРК','ФЕЙЕРВЕРКИ','ШОУ','ЗАЛПОВ','БАТАРЕЯ','САЛЮТОВ',
          'ВНИМАНИЕ','ОПАСНО','ИНСТРУКЦИЯ','СЕРВИС','ВЫСТРЕЛОВ','АРТИКУЛ','КАЛИБР'}
    candidates=[]
    for line in lines:
        box=line.get('box')
        if not box or len(box)!=4 or line.get('confidence',0)<.85:continue
        x,y,w,h=box
        if h<.055 or not (.18<x+w/2<.82 and .12<y+h/2<.82):continue
        tokens=[word for word in re.findall(r'[А-ЯЁA-Z]{4,}',line['text'].upper()) if word not in stop]
        if not tokens or len(tokens)>3:continue
        candidates.append((h,' '.join(tokens)))
    candidates.sort(reverse=True)
    if not candidates:return ''
    # Ambiguous large labels, e.g. more than one box in the frame.
    if len(candidates)>1 and candidates[1][0]>.8*candidates[0][0] and candidates[1][1]!=candidates[0][1]:return ''
    return candidates[0][1]


def cluster(photos,model=None,progress=lambda *_:None,cancel=lambda:False,reference=None,corrections=None):
    model=model or load_model();reference=references() if reference is None else reference
    corrections=corrections or {};n=len(photos);pairs={};groups=[[i] for i in range(n)]
    anchor={i:reference.get(p['sha256'],{}).get('group') for i,p in enumerate(photos)}
    def title(p):
        name=reference.get(p['sha256'],{}).get('name','')
        return p.get('main_title') or main_title([{'text':name,'confidence':1.0,'box':[.3,.3,.4,.1]}])
    def check():
        if cancel():raise InterruptedError('Поиск совпадений отменён.')
    def relation(i,j):
        a,b=photos[i],photos[j]
        if a.get('error') or b.get('error'):return -1
        key=':'.join(sorted((a['sha256'],b['sha256'])))
        if key in corrections:return 1 if corrections[key]['y'] else -1
        if anchor[i] and anchor[j]:return 1 if anchor[i]==anchor[j] else -1
        ka,kb=a['match'],b['match']
        if ka.get('conflict') or kb.get('conflict'):return -1
        if ka['strong'] and kb['strong']:return 1 if ka['key']==kb['key'] else -1
        ta,tb=title(a),title(b)
        if ta and tb and ta!=tb:return -1
        if a['sha256']==b['sha256']:return 1
        return 0
    total=n*(n-1)//2;done=0
    for i in range(n):
        for j in range(i+1,n):
            check();kind=relation(i,j)
            a,b=sorted((photos[i],photos[j]),key=lambda p:p['sha256'])
            score=1.0 if kind==1 else 0.0 if kind==-1 else learned_affinity(a,b,model)
            pairs[i,j]=(kind,score);done+=1
            if done%20==0 or done==total:progress(done,max(1,total),'Сравниваем товары во всей папке')
    def evidence(g,h):
        values=[pairs[min(i,j),max(i,j)] for i in g for j in h]
        if any(kind==-1 for kind,_ in values):return None
        if any(kind==1 for kind,_ in values):return (2.0,'Подтверждённое совпадение: разметка, артикул или дубликат')
        scores=[score for _,score in values];average=sum(scores)/len(scores)
        # Complete-link floor prevents a chain of similar backgrounds merging everything.
        one_known=bool(any(anchor[i] for i in g)) != bool(any(anchor[i] for i in h))
        if one_known and not any(title(photos[i]) and title(photos[i])==title(photos[j]) for i in g for j in h):
            return None
        threshold=.94 if one_known else .90
        floor=.75
        if average>=threshold and min(scores)>=floor:
            return average,'Визуальное сходство независимо от порядка файлов — проверить'
        return None
    while True:
        check();best=None
        for i,g in enumerate(groups):
            for j in range(i+1,len(groups)):
                value=evidence(g,groups[j])
                if value and (best is None or value[0]>best[0]):best=(value[0],i,j)
        if best is None:break
        _,i,j=best;groups[i]+=groups.pop(j)
    result=[]
    for indices in sorted(groups,key=min):
        indices.sort();members=[photos[i] for i in indices]
        names=[reference.get(p['sha256'],{}).get('name','') for p in members]
        strong=next((p['match'] for p in members if p['match']['strong']),None)
        known=any(anchor[i] for i in indices)
        result.append(dict(id=uuid.uuid4().hex[:12],photo_ids=[p['id'] for p in members],
            name=next((name for name in names if name),'') or (strong['name'] if strong else ''),
            sku=strong['sku'] if strong else '',status='pending',needs_review=True,
            confidence=.25 if any(p.get('error') for p in members) else .9 if known else .65 if len(members)>1 else .4,
            reasons=['Облако: подтверждённая разметка по содержимому файлов; порядок не учитывается' if known else
                     'Облако: сравнение по всей папке; нет ограничения по длине серии']))
    membership={pid:g['id'] for g in result for pid in g['photo_ids']}
    boundaries=[dict(left=photos[i-1]['id'],right=photos[i]['id'],split=membership[photos[i-1]['id']]!=membership[photos[i]['id']],
                    confidence=.5,reason='Перемешанные файлы: соседство не является границей товара',signals={}) for i in range(1,n)]
    return result,boundaries
