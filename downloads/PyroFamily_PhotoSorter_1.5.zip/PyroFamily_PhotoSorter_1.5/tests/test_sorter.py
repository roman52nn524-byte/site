import copy
import csv
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
from PIL import Image, ImageDraw
from pyro_sorter.catalog import Catalog, normalize
from pyro_sorter.features import Vision, digest
from pyro_sorter.engine import analyze, segment
from pyro_sorter.storage import atomic_json, export_project, validate
from pyro_sorter.app import create_app
from pyro_sorter.evaluate import evaluate


def fixture(root):
    source = root/'Фото товаров'
    source.mkdir()
    catalog = root/'catalog.csv'
    catalog.write_text('_NAME_;_MODEL_;_CATEGORY_;_MANUFACTURER_\nЗимняя радость;SB173;Салюты;Тест\nЗвон бокалов;ASB113;Салюты;Тест\n', encoding='utf-8-sig')
    prior = root/'review.csv'
    with prior.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['source', 'ocr_text'])
        writer.writeheader()
        for i in range(1, 6):
            image = Image.new('RGB', (320, 420), '#ae342f' if i <= 3 else '#274f93')
            draw = ImageDraw.Draw(image)
            draw.rectangle((40, 40, 280, 380), outline='yellow', width=5)
            draw.text((70, 100), ('SB173' if i <= 3 else 'ASB113')+' VIEW '+str(i), fill='white')
            path = source/f'IMG_{1500+i}.jpeg'
            image.save(path)
            writer.writerow({'source': str(path), 'ocr_text': 'Артикул '+('SB173' if i <= 3 else 'ASB113')})
    return source, catalog, prior


class SorterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.source, self.catalog_path, self.prior = fixture(self.root)

    def tearDown(self):
        self.tmp.cleanup()

    def project(self):
        return analyze(self.source, self.catalog_path, self.root/'cache', ocr=False, prior=self.prior)

    def test_catalog_and_homoglyphs(self):
        self.assertEqual(normalize('ТКВ013'), normalize('TKB013'))
        self.assertEqual(normalize('БСП0504915'), normalize('BSP0504915'))
        self.assertEqual(normalize('SB1O4'), normalize('SB104'))
        c = Catalog(self.catalog_path)
        self.assertTrue(c.identify('Артикул SB 173')['strong'])
        self.assertFalse(c.identify('Зимняя радость')['strong'])
        self.assertEqual(c.identify('Артикул БСП0504915')['method'], 'unknown_sku')
        self.assertTrue(c.identify('SB173 ASB113')['conflict'])

    def test_duplicate_catalog_ambiguous(self):
        with self.catalog_path.open('a') as f:
            f.write('Другой товар;SB173;Салюты;Тест\n')
        c = Catalog(self.catalog_path)
        self.assertTrue(c.identify('SB173')['conflict'])
        self.assertTrue(c.warnings)

    def test_fuzzy_is_not_strong(self):
        c = Catalog(self.catalog_path)
        self.assertFalse(c.identify('ASB118')['strong'])
        self.assertFalse(c.identify('SB173', .4)['strong'])

    def test_end_to_end_segmentation_and_metrics(self):
        p = self.project()
        self.assertEqual([len(g['photo_ids']) for g in p['groups']], [3, 2])
        truth = {'kind': 'synthetic_with_injected_ocr', 'photos': {f'IMG_{1500+i}.jpeg': {'group': 'A' if i <= 3 else 'B', 'sku': 'SB173' if i <= 3 else 'ASB113', 'catalog_sku': 'SB173' if i <= 3 else 'ASB113'} for i in range(1, 6)}}
        metrics = evaluate(p, truth)
        self.assertEqual(metrics['false_merge_pairs'], 0)
        self.assertEqual(metrics['boundary_f1'], 1)
        self.assertEqual(metrics['sku_accuracy'], 1)

    def test_more_than_ten_views_allowed(self):
        c = Catalog(self.catalog_path)
        rows = [{'id': str(i), 'source': str(self.source/f'IMG_{i}.jpg'), 'sha256': str(i), 'match': c.identify('SB173'), 'features': {'timestamp': None}} for i in range(14)]
        groups, _ = segment(rows)
        self.assertEqual(len(groups), 1)

    def test_conflict_through_unknown_does_not_merge(self):
        c = Catalog(self.catalog_path)
        def row(i, text):
            return {'id': str(i), 'source': str(self.source/f'IMG_{i}.jpg'), 'sha256': str(i), 'match': c.identify(text), 'features': {'timestamp': None}, 'text_tokens': ['COMMON', 'PACKAGING']}
        with patch('pyro_sorter.engine.compare', return_value={'color': .99, 'local': .5, 'embedding': None}):
            groups, _ = segment([row(1,'SB173'), row(2,''), row(3,'ASB113')])
        self.assertEqual([len(g['photo_ids']) for g in groups], [2, 1])

    def test_missing_visual_evidence_not_joined_by_sequence(self):
        c = Catalog()
        rows = [{'id': str(i), 'source': str(self.source/f'IMG_{i}.jpg'), 'sha256': str(i), 'match': c.identify(''), 'features': {'timestamp': None}, 'text_tokens': []} for i in range(3)]
        with patch('pyro_sorter.engine.compare', return_value={'color': 1, 'local': 0, 'embedding': None}):
            groups, _ = segment(rows)
        self.assertEqual(len(groups), 3)

    def test_automatic_groups_without_ocr(self):
        p = analyze(self.source, None, self.root/'cache', ocr=False)
        self.assertEqual([len(g['photo_ids']) for g in p['groups']], [3, 2])
        self.assertEqual(p['grouping_mode'], 'auto')
        for g in p['groups']:
            g['status'] = 'approved'
        result = export_project(p, self.root/'auto-result')
        self.assertEqual(result['copied'], 5)
        self.assertEqual(len(list((self.root/'auto-result').glob('*/'))), 2)

    def test_auto_respects_hard_boundaries(self):
        c = Catalog(self.catalog_path)
        def row(i, text='', folder='same', stamp=None):
            return {'id': str(i), 'source': str(self.source/folder/f'IMG_{i}.jpg'),
                    'sha256': str(i), 'match': c.identify(text),
                    'features': {'timestamp': stamp}, 'text_tokens': []}
        sim = {'color': .95, 'local': 0, 'embedding': None}
        with patch('pyro_sorter.engine.compare', return_value=sim):
            for mode in ('auto', 'series'):
                groups, _ = segment([row(1,'SB173'), row(2), row(3,'ASB113')], mode)
                self.assertEqual([len(g['photo_ids']) for g in groups], [2,1])
                for rows in ([row(1),row(8)], [row(1),row(2,folder='other')],
                             [row(1,stamp=0),row(2,stamp=4000)]):
                    self.assertEqual(len(segment(rows,mode)[0]),2)
                self.assertEqual(len(segment([row(i) for i in range(14)],mode)[0]),1)

    def test_auto_prevents_color_chain_drift(self):
        c = Catalog()
        rows = [{'id': str(i), 'source': str(self.source/f'IMG_{i}.jpg'),
                 'sha256': str(i), 'match': c.identify(''),
                 'features': {'timestamp': None}, 'text_tokens': []} for i in range(3)]
        def similarity(a,b):
            return {'color': .8 if abs(int(a['id'])-int(b['id'])) <= 1 else .3,
                    'local':0, 'embedding':None}
        with patch('pyro_sorter.engine.compare', side_effect=similarity):
            self.assertEqual([len(g['photo_ids']) for g in segment(rows,'auto')[0]], [2,1])

    def test_free_views_and_reverse_side(self):
        c=Catalog(self.catalog_path)
        def row(i,text=''):
            return {'id':str(i),'source':str(self.source/f'IMG_{i}.jpg'),
                    'sha256':str(i),'match':c.identify(text),
                    'features':{'timestamp':None},'text_tokens':[]}
        def similarity(a,b):
            pair={int(a['id']),int(b['id'])}
            detail=.09 if pair in ({1,2},{1,4}) else 0
            return {'color':.3,'local':0,'embedding':None,'region_color':.4,'detail':detail}
        with patch('pyro_sorter.engine.compare',side_effect=similarity):
            groups,boundaries=segment([row(i) for i in range(1,6)],'free')
            self.assertEqual([len(g['photo_ids']) for g in groups],[4,1])
            self.assertTrue(any('обратный ракурс' in b['reason'] for b in boundaries))
            groups,_=segment([row(1,'SB173'),row(2),row(3,'ASB113'),row(4)],'free')
            self.assertEqual([len(g['photo_ids']) for g in groups],[2,1,1])

    def test_sift_rotation_and_scale(self):
        import numpy as np
        from pyro_sorter.features import compare
        rng=np.random.default_rng(42)
        im=Image.new('RGB',(320,320),'white')
        draw=ImageDraw.Draw(im)
        for _ in range(100):
            x,y=rng.integers(5,290,2);size=int(rng.integers(5,25))
            draw.ellipse((int(x),int(y),int(x)+size,int(y)+size),fill=tuple(int(v) for v in rng.integers(0,220,3)))
        a=self.root/'a.png';b=self.root/'b.png'
        im.save(a);im.rotate(90).resize((480,480)).save(b)
        v=Vision(self.root/'cache',False)
        result=compare({'features':v.extract(a,digest(a))},{'features':v.extract(b,digest(b))})
        self.assertGreater(result['detail'],.045)

    def smart_rows(self, labels, skus=None):
        c=Catalog(self.catalog_path)
        return [{'id':str(i),'filename':f'IMG_{i}.jpg','source':str(self.source/f'IMG_{i}.jpg'),
                 'sha256':str(i),'match':c.identify((skus or {}).get(i,'')),
                 'features':{'timestamp':None},'text_tokens':[],'label':label}
                for i,label in enumerate(labels)]

    def test_smart_mixed_lengths_and_hidden_sides(self):
        rows=self.smart_rows(['A','A','back','A','A']+['B']*7+['C']*3+['D']*10)
        def score(a,b):
            return .95 if a['label']==b['label'] else .08
        with patch('pyro_sorter.smart.affinity',side_effect=score):
            groups,_=segment(rows,'smart')
        self.assertEqual([len(g['photo_ids']) for g in groups],[5,7,3,10])
        self.assertTrue(any('IMG_2.jpg' in r for r in groups[0]['reasons']))

    def test_smart_hard_boundaries_and_cancel(self):
        from pyro_sorter.smart import segment_smart
        rows=self.smart_rows(['A']*8,{0:'SB173',4:'ASB113'})
        with patch('pyro_sorter.smart.affinity',return_value=.99):
            groups,_=segment(rows,'smart')
            for g in groups:
                keys={rows[int(i)]['match']['key'] for i in g['photo_ids'] if rows[int(i)]['match']['strong']}
                self.assertLessEqual(len(keys),1)
            rows[3]['error']='broken'
            groups,_=segment(rows,'smart')
            self.assertEqual(next(g['photo_ids'] for g in groups if '3' in g['photo_ids']),['3'])
            with self.assertRaises(InterruptedError):
                segment_smart(rows,cancel=lambda:True)

    def test_smart_without_ocr_real_features(self):
        p=analyze(self.source,None,self.root/'cache',ocr=False,mode='smart')
        self.assertEqual([len(g['photo_ids']) for g in p['groups']],[3,2])
        validate(p)

    def test_learned_model_names_and_sku_conflicts(self):
        from pyro_sorter.pair_model import load_model, predict
        from pyro_sorter.smart import learned_affinity
        model=load_model()
        signals={'color':.6,'region_color':.7,'center_color':.6,'local':.05,'detail':.07}
        self.assertTrue(0<predict(signals,model)<1)
        rows=self.smart_rows(['A','A'])
        with patch('pyro_sorter.smart.compare',return_value=signals):
            before=learned_affinity(rows[0],rows[1],model)
            rows[0]['filename']='totally-different-name.png'
            rows[0]['source']='/elsewhere/renamed.png'
            self.assertEqual(before,learned_affinity(rows[0],rows[1],model))
        c=Catalog(self.catalog_path)
        rows[0]['match']=c.identify('SB173');rows[1]['match']=c.identify('ASB113')
        self.assertEqual(learned_affinity(rows[0],rows[1],model),0)

    def test_corrupt_and_duplicate(self):
        (self.source/'IMG_1506.jpeg').write_bytes((self.source/'IMG_1505.jpeg').read_bytes())
        (self.source/'IMG_1507.jpeg').write_bytes(b'broken image')
        with self.assertLogs(level='ERROR'):
            p = self.project()
        self.assertTrue(p['photos'][-1]['error'])
        self.assertTrue(p['photos'][-2]['duplicate_of'])
        validate(p)

    def test_cache_and_heic(self):
        import pillow_heif
        p = self.source/'test.heic'
        Image.new('RGB', (64,64), 'red').save(p, format='HEIF')
        v = Vision(self.root/'cache', enable_ocr=False)
        first = v.extract(p, digest(p))
        with patch('pyro_sorter.features.Image.open', side_effect=AssertionError('cache should avoid image decoding')):
            second = v.extract(p, digest(p))
        self.assertEqual(first, second)

    def test_exif_orientation_and_timestamp(self):
        p = self.source/'orient.jpg'
        exif = Image.Exif()
        exif[274] = 6
        exif[306] = '2026:10:30 12:34:56'
        Image.new('RGB',(120,60),'blue').save(p, exif=exif)
        f = Vision(self.root/'cache', False).extract(p,digest(p))
        self.assertIsNotNone(f['timestamp'])
        with Image.open(f['thumbnail']) as im:
            self.assertEqual(im.size,(60,120))

    def test_export_repeat_and_original_hashes(self):
        p = self.project()
        before = {x: digest(x) for x in self.source.iterdir()}
        for g in p['groups']:
            g['status'] = 'approved'
        first = export_project(p,self.root/'Результат')
        second = export_project(p,self.root/'Результат')
        self.assertEqual(first['copied'],5)
        self.assertEqual(second['skipped'],5)
        self.assertEqual(before,{x:digest(x) for x in self.source.iterdir()})
        with self.assertRaises(ValueError):
            export_project(p,self.source/'result')

    def test_export_collision_and_changed_source(self):
        p=self.project()
        for g in p['groups']:g['status']='approved'
        export_project(p,self.root/'out')
        target=next((self.root/'out').rglob('*.jpeg'))
        target.write_bytes(b'different')
        with self.assertRaises(ValueError):export_project(p,self.root/'out')
        self.assertEqual(target.read_bytes(),b'different')
        Path(p['photos'][0]['source']).write_bytes(b'changed original')
        with self.assertRaises(ValueError):export_project(p,self.root/'another')

    def test_api_session_revision_membership(self):
        app=create_app(self.root/'home')
        client=app.test_client()
        token=app.extensions['sorter']['token']
        headers={'X-Session-Token':token}
        self.assertEqual(client.get('/api/state').status_code,403)
        self.assertEqual(client.post('/api/cancel',json={},headers={**headers,'Origin':'https://evil.test'}).status_code,403)
        p=self.project();path=self.root/'project.json';atomic_json(path,p)
        self.assertEqual(client.post('/api/open',json={'path':str(path)},headers=headers).status_code,200)
        bad=copy.deepcopy(p['groups']);bad[0]['photo_ids'].append(bad[1]['photo_ids'][0])
        with self.assertLogs(level='ERROR'):
            self.assertEqual(client.post('/api/save',json={'revision':0,'groups':bad},headers=headers).status_code,400)
        with self.assertLogs(level='ERROR'):
            self.assertEqual(client.post('/api/save',json={'revision':-1,'groups':p['groups']},headers=headers).status_code,400)
        changed=copy.deepcopy(p['groups']);changed[0]['name']='New';changed[0]['status']='approved'
        response=client.post('/api/save',json={'revision':0,'groups':changed},headers=headers)
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json['project']['groups'][0]['status'],'pending')
        self.assertTrue(path.with_suffix('.backup.json').exists())
        with client.get('/photo/'+p['photos'][0]['id'],headers=headers) as response:
            self.assertEqual(response.status_code,200)
        self.assertEqual(client.get('/photo/not-known',headers=headers).status_code,404)

    def test_cancel(self):
        with self.assertRaises(InterruptedError):
            analyze(self.source,self.catalog_path,self.root/'cache',cancel=lambda:True,ocr=False)

    def test_validation_and_atomic_roundtrip(self):
        p=self.project();target=self.root/'проект.json';atomic_json(target,p)
        self.assertEqual(validate(json.loads(target.read_text())),p)
        p['groups'][0]['photo_ids']=[]
        with self.assertRaises(ValueError):validate(p)


if __name__=='__main__':unittest.main()
