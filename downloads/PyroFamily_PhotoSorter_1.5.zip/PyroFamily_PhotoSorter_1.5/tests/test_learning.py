import copy
import json
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch
import numpy as np
from test_sorter import fixture
from pyro_sorter.engine import analyze
from pyro_sorter.learning import Learning, initialize, collect, metrics
from pyro_sorter.storage import atomic_json
from pyro_sorter.app import create_app
from pyro_sorter.pair_model import load_model


class LearningTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name)
        source,catalog,prior=fixture(self.root)
        self.project=analyze(source,catalog,self.root/'cache',ocr=False,prior=prior)
        self.home=self.root/'home';self.learning=Learning(self.home)

    def tearDown(self):self.tmp.cleanup()

    def moved(self):
        p=copy.deepcopy(self.project)
        photo=p['groups'][0]['photo_ids'].pop();p['groups'][1]['photo_ids'].append(photo)
        initialize(p,self.project)
        return p

    def test_saved_correction_and_undo_survive_restart(self):
        p=self.moved();self.learning.remember(p)
        self.assertEqual(Learning(self.home).status()['examples'],4)
        restored=copy.deepcopy(p);restored['groups']=copy.deepcopy(self.project['groups'])
        initialize(restored,p);self.learning.remember(restored)
        self.assertEqual(self.learning.status()['examples'],0)

    def test_approval_and_rename_are_not_labels(self):
        p=copy.deepcopy(self.project)
        for g in p['groups']:g.update(status='approved',name='renamed')
        initialize(p,self.project)
        self.assertEqual(collect(p),{})

    def test_conflicting_projects_excluded(self):
        p=self.moved();self.learning.remember(p)
        q=copy.deepcopy(p);q['id']='another';q['learning_baseline']={}
        q['groups']=copy.deepcopy(self.project['groups'])
        ids=[x['id'] for x in q['photos']]
        q['review_votes']={ids[2]:{'compared':ids}}
        self.learning.remember(q)
        self.assertEqual(self.learning.status()['conflicts'],4)
        self.assertEqual(self.learning.status()['examples'],0)

    def test_rollback_survives_restart(self):
        model=load_model();model['weights'][0]+=1
        atomic_json(self.learning.root/'models'/'personal.json',model)
        atomic_json(self.learning.file,{'active':'personal.json','history':[None],'report':{}})
        self.assertEqual(Learning(self.home).active(),model)
        self.learning.rollback()
        self.assertEqual(Learning(self.home).active(),load_model())
        with self.assertRaises(ValueError):self.learning.rollback()

    def client(self):
        app=create_app(self.home);client=app.test_client();headers={'X-Session-Token':app.extensions['sorter']['token']}
        path=self.root/'project.json';atomic_json(path,self.project)
        client.post('/api/open',json={'path':str(path)},headers=headers)
        return client,headers

    def wait(self,client,headers):
        for _ in range(300):
            state=client.get('/api/state',headers=headers).json
            if not state['job']['running']:return state
            time.sleep(.01)
        self.fail('Background job timeout')

    def test_review_save_stale_and_undo(self):
        client,h=self.client();a=self.project['groups'][0];b=self.project['groups'][1];pid=a['photo_ids'][-1]
        queue={'revision':0,'questions':[dict(photo_id=pid,current=a['id'],alternative=b['id'],own_score=.4,alternative_score=.5,priority=.1,reason='test')],'failures':{}}
        with patch('pyro_sorter.app.build_queue',return_value=queue):
            client.post('/api/review/build',json={},headers=h);self.wait(client,h)
        result=client.post('/api/review/decide',json={'revision':0,'photo_id':pid,'target':b['id']},headers=h)
        self.assertEqual(result.status_code,200)
        self.assertEqual(result.json['learning']['examples'],4)
        self.assertIn(pid,result.json['project']['groups'][1]['photo_ids'])
        with self.assertLogs(level='ERROR'):
            stale=client.post('/api/review/decide',json={'revision':0,'photo_id':pid,'target':a['id']},headers=h)
        self.assertEqual(stale.status_code,400)
        result=client.post('/api/review/undo',json={'revision':1},headers=h)
        self.assertEqual(result.status_code,200)
        self.assertEqual(result.json['learning']['examples'],0)
        self.assertEqual(result.json['project']['groups'],self.project['groups'])

    def test_keep_answer_supplies_labels_without_move(self):
        client,h=self.client();a,b=self.project['groups'];pid=a['photo_ids'][0]
        queue={'revision':0,'questions':[dict(photo_id=pid,current=a['id'],alternative=b['id'])],'failures':{}}
        with patch('pyro_sorter.app.build_queue',return_value=queue):
            client.post('/api/review/build',json={},headers=h);self.wait(client,h)
        response=client.post('/api/review/decide',json={'revision':0,'photo_id':pid,'target':a['id']},headers=h)
        self.assertEqual(response.status_code,200)
        self.assertEqual(response.json['learning']['examples'],4)
        self.assertEqual(response.json['project']['groups'],self.project['groups'])

    def test_cancel_does_not_replace_model(self):
        self.learning.remember(self.moved())
        with self.assertRaises(InterruptedError):self.learning.train(cancel=lambda:True)
        self.assertFalse(self.learning.file.exists())

    def test_actual_training_promotes_and_rolls_back(self):
        self.learning.remember(self.moved())
        weak=load_model();weak['weights']=[0]*len(weak['weights'])
        atomic_json(self.learning.root/'models'/'weak.json',weak)
        atomic_json(self.learning.file,{'active':'weak.json','history':[None],'report':None})
        result=self.learning.train()
        self.assertTrue(result['accepted'],result)
        self.assertLess(result['new']['loss'],result['old']['loss'])
        self.assertNotEqual(Learning(self.home).active(),weak)
        self.learning.rollback()
        self.assertEqual(Learning(self.home).active(),weak)

    def test_retraining_gate_and_disjoint_validation(self):
        # Deterministic synthetic dataset exercises the full training path,
        # including source verification. No claim of visual accuracy.
        self.learning.remember(self.moved())
        seed=json.loads((Path(__file__).resolve().parents[1]/'pyro_sorter/learning_seed.json').read_text())
        import hashlib
        def held(sha):return int(hashlib.sha256(('validation-v1:'+sha).encode()).hexdigest()[:8],16)%4==0
        train_ids={i for p in seed if all(not held(i) for i in p['ids']) for i in p['ids']}
        test_ids={i for p in seed if all(held(i) for i in p['ids']) for i in p['ids']}
        self.assertFalse(train_ids & test_ids)
        # Explicitly equal scores reject a candidate, preserving active version.
        with patch('pyro_sorter.learning.metrics',return_value={'loss':.5,'errors':2,'pairs':10}):
            try:report=self.learning.train()
            except ValueError as e:
                if 'обучающей части' not in str(e):raise
                self.skipTest('Fixture images happen to be held out')
        self.assertFalse(report['accepted']);self.assertIsNone(self.learning.state()['active'])
        with patch('pyro_sorter.learning.metrics',side_effect=[{'loss':.5,'errors':2,'pairs':10},{'loss':.4,'errors':1,'pairs':10}]):report=self.learning.train()
        self.assertTrue(report['accepted']);self.assertTrue(self.learning.status()['can_rollback'])
        self.learning.rollback();self.assertEqual(self.learning.active(),load_model())


if __name__=='__main__':unittest.main()
