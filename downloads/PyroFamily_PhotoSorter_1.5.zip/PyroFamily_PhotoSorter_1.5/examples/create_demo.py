"""Synthetic pipeline demo, not a warehouse-quality benchmark."""
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tests'))
from test_sorter import fixture
from pyro_sorter.engine import analyze
from pyro_sorter.evaluate import evaluate
from pyro_sorter.storage import atomic_json, export_project

parser=argparse.ArgumentParser(description='Создать искусственный пример, не трогая реальные фотографии')
parser.add_argument('output',type=Path)
args=parser.parse_args()
root=args.output.expanduser().resolve()
if root.exists():
    raise SystemExit('Выберите новую несуществующую папку для демо.')
root.mkdir(parents=True)
source,catalog,prior=fixture(root)
project=analyze(source,catalog,root/'cache',ocr=False,prior=prior)
truth={'kind':'synthetic_with_injected_ocr','photos':{f'IMG_{1500+i}.jpeg':{'group':'A' if i<=3 else 'B','sku':'SB173' if i<=3 else 'ASB113','catalog_sku':'SB173' if i<=3 else 'ASB113'} for i in range(1,6)}}
for g in project['groups']:
    g['status']='approved'  # Ground truth is known by construction only in this demo.
atomic_json(root/'project.json',project)
atomic_json(root/'truth.json',truth)
metrics=evaluate(project,truth)
atomic_json(root/'metrics.json',metrics)
print(json.dumps(metrics,ensure_ascii=False,indent=2))
print(export_project(project,root/'Результат'))
print('Демо-проект:',root/'project.json')
