#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if [ ! -x .venv/bin/python ]; then
  echo 'Сначала запустите Install.command'
  exit 1
fi
exec .venv/bin/python -m pyro_sorter.app
