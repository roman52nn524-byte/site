#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
PYRO_PYTHON=""
for candidate in python3.13 python3.12 python3.11 python3; do
  if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; assert (3,11) <= sys.version_info[:2] <= (3,13)' 2>/dev/null; then
    PYRO_PYTHON="$candidate"
    break
  fi
done
if [ -z "$PYRO_PYTHON" ]; then
  echo 'Установите Python 3.11–3.13 для macOS с python.org, затем повторите установку.'
  exit 1
fi
"$PYRO_PYTHON" -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
echo 'Готово. Запустите Start.command. Для Apple Vision нужны Command Line Tools: xcode-select --install'
