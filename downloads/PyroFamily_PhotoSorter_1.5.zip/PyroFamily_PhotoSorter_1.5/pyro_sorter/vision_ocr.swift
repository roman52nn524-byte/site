import Foundation
import Vision
import AppKit
for line in AnyIterator({readLine()}) {
    var lines: [[String: Any]] = []
    var errorMessage: String? = nil
    var languageWarning: String? = nil
    do {
        guard let image = NSImage(contentsOfFile: line), let data = image.tiffRepresentation,
              let rep = NSBitmapImageRep(data: data), let cg = rep.cgImage else {
            throw NSError(domain: "PhotoSorter", code: 1, userInfo: [NSLocalizedDescriptionKey: "Не удалось прочитать изображение"])
        }
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        let supported = try request.supportedRecognitionLanguages()
        request.recognitionLanguages = ["ru-RU", "en-US"].filter { supported.contains($0) }
        if !supported.contains("ru-RU") { languageWarning = "Эта версия Apple Vision не поддерживает русский OCR. Доступны: " + supported.joined(separator: ", ") }
        request.usesLanguageCorrection = false
        try VNImageRequestHandler(cgImage: cg).perform([request])
        lines = (request.results ?? []).compactMap { item in
            guard let t = item.topCandidates(1).first else {return nil}
            return ["text": t.string, "confidence": Double(t.confidence)]
        }
    } catch {errorMessage = error.localizedDescription}
    var result: [String: Any] = ["lines": lines]
    if let e = errorMessage {result["error"] = e}
    if let warning = languageWarning {result["warning"] = warning}
    let data = try! JSONSerialization.data(withJSONObject: result)
    print(String(data: data, encoding: .utf8)!)
    fflush(stdout)
}
