import csv
import re
import unicodedata
from collections import defaultdict
from difflib import SequenceMatcher


def normalize(value):
    s = unicodedata.normalize('NFKC', str(value)).upper().replace('Ё', 'Е')
    s = re.sub(r'[^A-ZА-Я0-9]', '', s)
    s = s.translate(str.maketrans('АВСЕНКМОРТХ', 'ABCEHKMOPTX'))
    # Known catalogue prefix; do not transliterate arbitrary product names/codes.
    s = re.sub(r'^БCП(?=[0-9O])', 'BSP', s)
    m = re.fullmatch(r'(.*?)([0-9OОIІL]+)', s)
    if m and any(c.isdigit() for c in m[2]):
        s = m[1] + m[2].translate(str.maketrans({'O': '0', 'О': '0', 'I': '1', 'І': '1', 'L': '1'}))
    return s


def words(s):
    stop = {'САЛЮТ', 'ФЕЙЕРВЕРК', 'ЗАЛПОВ', 'КАЛИБР', 'ФОНТАН', 'АРТИКУЛ', 'ПРОИЗВОДИТЕЛЬ', 'ВНИМАНИЕ', 'СОСТАВ', 'ГОСТ', 'ХРАНЕНИЯ'}
    return set(re.findall(r'[А-ЯA-Z]{4,}', str(s).upper())) - stop


class Catalog:
    def __init__(self, path=None):
        self.rows = []
        self.index = defaultdict(list)
        self.warnings = []
        if path:
            raw = path.read_bytes()
            try:
                body = raw.decode('utf-8-sig')
            except UnicodeDecodeError:
                body = raw.decode('cp1251')
            first = body.splitlines()[0]
            delimiter = max([';', '\t', ','], key=first.count)
            reader = csv.DictReader(body.splitlines(keepends=True), delimiter=delimiter)
            if not {'_NAME_', '_MODEL_'}.issubset(reader.fieldnames or []):
                raise ValueError('В CSV нужны колонки _NAME_ и _MODEL_.')
            for r in reader:
                name, sku = (r.get('_NAME_') or '').strip(), (r.get('_MODEL_') or '').strip()
                if not name or not sku:
                    continue
                row = {'name': name, 'sku': sku, 'key': normalize(sku), 'category': r.get('_CATEGORY_') or r.get('_MAIN_CATEGORY_', ''), 'manufacturer': r.get('_MANUFACTURER_', '')}
                if row not in self.rows:
                    self.rows.append(row)
                    self.index[row['key']].append(row)
            self.warnings = [f'Неоднозначный артикул {k}: {len(v)} записей' for k, v in self.index.items() if len(v) > 1]

    def identify(self, text, ocr_confidence=1):
        tokens = re.findall(r'[A-ZА-ЯЁ0-9]+(?:[-/][A-ZА-ЯЁ0-9]+)*', text.upper())
        candidates = {normalize(t) for t in tokens}
        candidates |= {normalize(a + b) for a, b in zip(tokens, tokens[1:]) if re.fullmatch(r'[A-ZА-ЯЁ]+', a) and re.fullmatch(r'[0-9OОIІL]+', b)}
        hits = [k for k in candidates if k in self.index and len(k) >= 4]
        base = {'sku': '', 'name': '', 'key': '', 'strong': False, 'confidence': 0.0, 'method': 'unknown', 'candidates': [], 'conflict': False}
        if len(hits) > 1 or any(len(self.index[k]) > 1 for k in hits):
            return {**base, 'method': 'ambiguous_sku', 'conflict': True, 'candidates': [r for k in hits for r in self.index[k]]}
        if hits:
            r = self.index[hits[0]][0]
            return {**base, **r, 'strong': ocr_confidence >= .65, 'confidence': min(.97, ocr_confidence), 'method': 'sku'}
        # An explicit unknown model can still prevent merging different packages.
        explicit = re.search(r'(?:АРТИКУЛ|ART\.?|SKU|МОДЕЛЬ)\s*[:№#-]?\s*([A-ZА-ЯЁ]{1,8}[- ]?[0-9OОIІL]{2,12})', text.upper())
        if explicit:
            key = normalize(explicit[1])
            return {**base, 'sku': explicit[1].replace(' ', ''), 'key': key, 'strong': ocr_confidence >= .8, 'confidence': min(.85, ocr_confidence), 'method': 'unknown_sku'}
        # Fuzzy model and name matches are suggestions, never hard anchors.
        suggestions = []
        for k in candidates:
            if not (any(c.isdigit() for c in k) and any(c.isalpha() for c in k) and len(k) >= 5):
                continue
            for known, entries in self.index.items():
                if abs(len(k) - len(known)) <= 1 and SequenceMatcher(None, k, known).ratio() >= .87:
                    suggestions.extend(entries)
        if suggestions:
            return {**base, 'method': 'fuzzy_sku', 'confidence': .5, 'candidates': suggestions[:5]}
        observed = words(text)
        matches = []
        for r in self.rows:
            w = words(r['name'])
            overlap = w & observed
            if len(overlap) >= 2 or (len(w) == 1 and overlap and len(next(iter(w))) >= 6):
                matches.append((len(overlap) / max(1, len(w)), r))
        matches.sort(key=lambda x: x[0], reverse=True)
        if matches:
            return {**base, 'method': 'title_suggestion', 'confidence': .45, 'candidates': [r for _, r in matches[:5]]}
        return base
