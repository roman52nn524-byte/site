"""Local correction journal, disjoint-image validation and versioned personal models."""
import copy
import hashlib
import json
import math
import uuid
from pathlib import Path
import numpy as np
from .features import Vision, compare, digest
from .pair_model import load_model, vector, predict
from .storage import atomic_json
from .train import fit


def membership(project):
    return {pid:g['id'] for g in project['groups'] for pid in g['photo_ids']}


def initialize(project, original):
    project.setdefault('learning_baseline',membership(original))
    project.setdefault('review_votes',{})
    current,before=membership(project),membership(original)
    project['review_votes']={pid:vote for pid,vote in project['review_votes'].items()
        if pid in current and pid in before and all(other in current and other in before and
            (current[pid]==current[other])==(before[pid]==before[other]) for other in vote.get('compared',[]))}


def collect(project):
    """Only changed pair relations and explicit review votes, never bulk approval."""
    base=project.get('learning_baseline',{});current=membership(project)
    excluded={pid for g in project['groups'] if g['status']=='rejected' for pid in g['photo_ids']}
    photos=[p for p in project['photos'] if not p.get('error') and p['id'] not in excluded]
    examples={}
    def add(a,b,label):
        if a['sha256']==b['sha256']:return
        key=':'.join(sorted((a['sha256'],b['sha256'])))
        examples[key]={'a':{k:a[k] for k in ('id','source','sha256')},
                       'b':{k:b[k] for k in ('id','source','sha256')},'y':int(label)}
    for i,a in enumerate(photos):
        for b in photos[:i]:
            if a['id'] in base and b['id'] in base:
                before=base[a['id']]==base[b['id']];after=current[a['id']]==current[b['id']]
                if before!=after:add(b,a,after)
    byid={p['id']:p for p in photos}
    for pid,vote in project.get('review_votes',{}).items():
        if pid not in byid:continue
        for other in vote.get('compared',[]):
            if other in byid and other!=pid:
                add(byid[pid],byid[other],current[pid]==current[other])
    return examples


class Learning:
    def __init__(self,home):
        self.home=Path(home);self.root=self.home/'learning';self.root.mkdir(parents=True,exist_ok=True)
        (self.root/'feedback').mkdir(exist_ok=True)
        (self.root/'models').mkdir(exist_ok=True)
        self.file=self.root/'state.json'

    def state(self):
        return json.loads(self.file.read_text()) if self.file.exists() else {'active':None,'history':[],'report':None}

    def active(self):
        state=self.state()
        return json.loads((self.root/'models'/state['active']).read_text()) if state['active'] else load_model()

    def remember(self,project):
        name=hashlib.sha256(project['id'].encode()).hexdigest()+'.json'
        atomic_json(self.root/'feedback'/name,{'project':project['id'],'revision':project['revision'],'examples':collect(project)})

    def examples(self):
        merged={};conflicts=set()
        for path in sorted((self.root/'feedback').glob('*.json')):
            for key,value in json.loads(path.read_text())['examples'].items():
                if key in merged and merged[key]['y']!=value['y']:conflicts.add(key)
                merged[key]=value
        return {k:v for k,v in merged.items() if k not in conflicts},conflicts

    def status(self):
        state=self.state();examples,conflicts=self.examples()
        return dict(active=state['active'] or 'Встроенная 1.4',can_rollback=bool(state['history']),
                    examples=len(examples),conflicts=len(conflicts),report=state.get('report'))

    def rollback(self):
        state=self.state()
        if not state['history']:raise ValueError('Предыдущей версии модели нет.')
        state['active']=state['history'].pop();state['report']={'message':'Предыдущая модель восстановлена. Применится при новом анализе.'}
        atomic_json(self.file,state);return self.status()

    def train(self,progress=lambda *_:None,cancel=lambda:False):
        examples,conflicts=self.examples()
        if not examples:raise ValueError('Сначала сохраните исправления групп или решите спорные фото.')
        vision=Vision(self.home/'cache',False);rows={};feedback=[];missing=0
        def check():
            if cancel():raise InterruptedError('Обучение отменено. Модель не изменена.')
        for i,example in enumerate(examples.values()):
            check();progress(i,len(examples),'Подготовка сохранённых исправлений')
            try:
                pair=[]
                for p in (example['a'],example['b']):
                    sha=p['sha256']
                    if sha not in rows:
                        if digest(p['source'])!=sha:raise ValueError('Фото изменено')
                        rows[sha]={**p,'id':sha,'features':vision.extract(p['source'],sha)}
                    pair.append(rows[sha])
                feedback.append({'ids':sorted((pair[0]['sha256'],pair[1]['sha256'])),
                                 'x':vector(compare(*pair)),'y':example['y']})
            except (OSError,ValueError):missing+=1
        # Replay original numerical examples; no source images are distributed.
        seed=json.loads(Path(__file__).with_name('learning_seed.json').read_text())
        merged={':'.join(p['ids']):p for p in seed}
        merged.update({':'.join(p['ids']):p for p in feedback})
        # Conflicting feedback must not silently restore a seed label.
        for key in conflicts:merged.pop(key,None)
        samples=list(merged.values())
        def bucket(sha):return int(hashlib.sha256(('validation-v1:'+sha).encode()).hexdigest()[:8],16)%4==0
        training=[p for p in samples if not bucket(p['ids'][0]) and not bucket(p['ids'][1])]
        testing=[p for p in samples if bucket(p['ids'][0]) and bucket(p['ids'][1])]
        used=[p for p in feedback if not bucket(p['ids'][0]) and not bucket(p['ids'][1])]
        if not used:raise ValueError('Пока нет новых примеров в обучающей части. Добавьте исправления на других фото; часть снимков зарезервирована для проверки.')
        if any(sum(p['y']==label for p in training)<3 or sum(p['y']==label for p in testing)<2 for label in (0,1)):
            raise ValueError('Недостаточно разных примеров для раздельного обучения и проверки. Сохраните исправления ещё нескольких товаров.')
        check();progress(0,1,'Обучение и сравнение на отложенных фотографиях')
        incumbent=self.active();candidate={**incumbent,**fit(np.array([p['x'] for p in training]),np.array([p['y'] for p in training]))}
        old=metrics(incumbent,testing);new=metrics(candidate,testing)
        accepted=new['loss']<old['loss']-1e-6 and new['errors']<=old['errors']
        check();state=self.state();report=dict(message='Новая модель применена.' if accepted else 'Кандидат не улучшил проверку. Прежняя модель сохранена.',
            accepted=accepted,old=old,new=new,training_pairs=len(training),validation_pairs=len(testing),
            feedback_used=len(used),feedback_available=len(feedback),missing=missing,conflicts=len(conflicts),
            caveat='Проверка сходства пар, не гарантия качества групп. Проверочная часть постоянная; встроенная модель ранее видела исходные примеры.')
        name='model-'+uuid.uuid4().hex[:12]+'.json';atomic_json(self.root/'models'/name,candidate)
        if accepted:
            state['history'].append(state['active']);state['active']=name
        state['report']=report;atomic_json(self.file,state);progress(1,1,report['message'])
        return report


def metrics(model,samples):
    loss=0.;errors=0;fp=fn=0
    for p in samples:
        values=dict(zip(('color','region_color','center_color','local','detail'),p['x']))
        prob=max(1e-9,min(1-1e-9,predict(values,model)));y=p['y'];pred=prob>=.5
        loss-=y*math.log(prob)+(1-y)*math.log(1-prob)
        errors+=int(pred!=bool(y));fp+=int(pred and not y);fn+=int(not pred and y)
    return dict(loss=loss/len(samples),errors=errors,false_merges=fp,false_splits=fn,pairs=len(samples))
