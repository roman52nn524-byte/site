"""Evaluate a project against explicitly supplied labels; never invent real ground truth."""
import argparse
import json
from itertools import combinations
from pathlib import Path
from .catalog import normalize


def evaluate(project, truth):
    labels = truth['photos']
    keys = [Path(p['source']).relative_to(Path(project['source'])).as_posix() for p in project['photos']]
    if set(labels) != set(keys):
        raise ValueError('Разметка должна содержать ровно все относительные пути фотографий проекта.')
    assigned = {pid: g['id'] for g in project['groups'] for pid in g['photo_ids']}
    expected = [labels[k]['group'] for k in keys]
    actual = [assigned[p['id']] for p in project['photos']]
    boundaries_true = {i for i in range(1, len(keys)) if expected[i] != expected[i-1]}
    boundaries_pred = {i for i in range(1, len(keys)) if actual[i] != actual[i-1]}
    tp = len(boundaries_true & boundaries_pred)
    precision = tp/len(boundaries_pred) if boundaries_pred else (1.0 if not boundaries_true else 0.0)
    recall = tp/len(boundaries_true) if boundaries_true else 1.0
    merges = splits = 0
    for i, j in combinations(range(len(keys)), 2):
        merges += expected[i] != expected[j] and actual[i] == actual[j]
        splits += expected[i] == expected[j] and actual[i] != actual[j]
    sku_n = sku_ok = catalog_n = catalog_ok = 0
    for p, key in zip(project['photos'], keys):
        label = labels[key]
        if label.get('sku') is not None:
            sku_n += 1
            sku_ok += normalize(p['match'].get('sku', '')) == normalize(label['sku'])
        if label.get('catalog_sku') is not None:
            catalog_n += 1
            catalog_ok += p['match']['method'] == 'sku' and normalize(p['match'].get('sku', '')) == normalize(label['catalog_sku'])
    return {'dataset_kind': truth.get('kind', 'unspecified'), 'images': len(keys), 'boundary_precision': precision, 'boundary_recall': recall, 'boundary_f1': 2*precision*recall/(precision+recall) if precision+recall else 0, 'false_merge_pairs': merges, 'false_split_pairs': splits, 'sku_accuracy': sku_ok/sku_n if sku_n else None, 'sku_labeled_frames': sku_n, 'catalog_accuracy': catalog_ok/catalog_n if catalog_n else None, 'catalog_labeled_frames': catalog_n}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('project', type=Path)
    parser.add_argument('truth', type=Path)
    args = parser.parse_args()
    print(json.dumps(evaluate(json.loads(args.project.read_text()), json.loads(args.truth.read_text())), ensure_ascii=False, indent=2))
