"""Small supervised logistic model of visual pair similarity. No filename inputs."""
import json
import math
from pathlib import Path


def vector(signals):
    return [signals['color'],signals.get('region_color',signals['color']),
            signals.get('center_color',signals['color']),min(signals['local'],.5),
            min(signals.get('detail',0),.5)]


def predict(signals, model):
    features=vector(signals)
    z=model['weights'][0]+sum(w*(x-m)/s for x,m,s,w in
        zip(features,model['mean'],model['scale'],model['weights'][1:]))
    return 1/(1+math.exp(-max(-30,min(30,z))))


def load_model():
    return json.loads(Path(__file__).with_name('pair_model.json').read_text())
