import hashlib
import json
import os
import re
import shutil
import tempfile
from pathlib import Path
from .features import digest


def atomic_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix='.project-', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def validate(project):
    if project.get('schema') != 1:
        raise ValueError('Неизвестная версия проекта.')
    valid_id = lambda value: isinstance(value, str) and re.fullmatch(r'[a-zA-Z0-9_-]{1,80}', value)
    if not valid_id(project.get('id')) or not isinstance(project.get('revision'), int) or project['revision'] < 0:
        raise ValueError('Некорректный идентификатор или ревизия проекта.')
    if not isinstance(project.get('photos'), list) or not isinstance(project.get('groups'), list):
        raise ValueError('Некорректная структура проекта.')
    for photo in project['photos']:
        if not valid_id(photo.get('id')) or not isinstance(photo.get('source'), str):
            raise ValueError('Некорректный идентификатор фотографии.')
    for group in project['groups']:
        if not valid_id(group.get('id')) or not isinstance(group.get('photo_ids'), list):
            raise ValueError('Некорректный идентификатор группы.')
        if not all(isinstance(group.get(k), str) and len(group[k]) <= 250 for k in ('name', 'sku')):
            raise ValueError('Некорректное имя или артикул группы.')
        if not isinstance(group.get('confidence'), (float, int)) or not 0 <= group['confidence'] <= 1:
            raise ValueError('Некорректная уверенность группы.')
    ids = [p['id'] for p in project['photos']]
    assigned = [i for g in project['groups'] for i in g['photo_ids']]
    if len(ids) != len(set(ids)) or sorted(ids) != sorted(assigned):
        raise ValueError('Каждое фото должно находиться ровно в одной группе.')
    gids = [g['id'] for g in project['groups']]
    if len(gids) != len(set(gids)) or any(not g['photo_ids'] for g in project['groups']):
        raise ValueError('Пустая группа или повтор ID группы.')
    if any(g['status'] not in ('pending', 'approved', 'rejected') for g in project['groups']):
        raise ValueError('Неизвестный статус группы.')
    return project


def safe_name(value):
    value = re.sub(r'[\\/:*?"<>|\x00-\x1f]', '_', str(value)).strip(' .')[:100]
    return value or 'Неопознанные'


def export_project(project, destination):
    validate(project)
    dest = Path(destination).expanduser().resolve()
    source_root = Path(project['source']).resolve()
    if dest == source_root or source_root in dest.parents:
        raise ValueError('Папка экспорта должна находиться вне папки исходников.')
    approved = [g for g in project['groups'] if g['status'] == 'approved']
    if not approved:
        raise ValueError('Сначала подтвердите хотя бы одну группу.')
    photos = {p['id']: p for p in project['photos']}
    plan = []
    for g in approved:
        label = ' — '.join(v for v in [g['name'].strip(), g['sku'].strip()] if v) or 'Неопознанные'
        # Stable group suffix prevents different products with equal names from collapsing.
        folder = safe_name(label) + ' [' + safe_name(g['id'])[:12] + ']'
        for pid in g['photo_ids']:
            p = photos[pid]
            src = Path(p['source'])
            if p.get('error') or not src.is_file():
                raise ValueError('Недоступное фото в подтверждённой группе: '+src.name)
            if digest(src) != p['sha256']:
                raise ValueError('Оригинал изменился после анализа: '+src.name)
            name = safe_name(src.stem) + '__' + safe_name(pid)[:16] + src.suffix.lower()
            target = dest / folder / name
            if target.parent.resolve() != dest / folder:
                raise ValueError('Символическая ссылка в пути экспорта запрещена.')
            if target.is_symlink():
                raise ValueError('Целевой файл — символическая ссылка.')
            if target.exists() and digest(target) != p['sha256']:
                raise ValueError('Коллизия: существующий файл отличается: '+str(target))
            plan.append((src, target, p['sha256'], pid))
    copied = skipped = 0
    for src, target, sha, pid in plan:
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            skipped += 1
            continue
        # Exclusive creation, never overwrite; remove only this operation's incomplete copy.
        try:
            with target.open('xb') as output, src.open('rb') as inp:
                shutil.copyfileobj(inp, output)
                output.flush()
                os.fsync(output.fileno())
        except FileExistsError:
            if target.is_symlink() or digest(target) != sha:
                raise ValueError('Коллизия при экспорте: '+str(target))
            skipped += 1
            continue
        except Exception:
            target.unlink(missing_ok=True)
            raise
        if digest(target) != sha:
            target.unlink()
            raise ValueError('Проверка контрольной суммы копии не прошла.')
        copied += 1
    manifest = {'project_id': project['id'], 'revision': project['revision'], 'files': [{'id': pid, 'source': str(src), 'copy': str(target), 'sha256': sha} for src, target, sha, pid in plan]}
    manifest_path = dest / ('export-' + project['id'][:12] + '-r' + str(project['revision']) + '.json')
    if manifest_path.is_symlink():
        raise ValueError('Файл манифеста является ссылкой.')
    if manifest_path.exists():
        if json.loads(manifest_path.read_text()) != manifest:
            raise ValueError('Существующий манифест отличается. Выберите другую папку.')
    else:
        # Manifest is immutable; repeated export reuses it.
        with manifest_path.open('x', encoding='utf-8') as f:
            json.dump(manifest, f, ensure_ascii=False, indent=2)
    return {'copied': copied, 'skipped': skipped, 'directory': str(dest)}
