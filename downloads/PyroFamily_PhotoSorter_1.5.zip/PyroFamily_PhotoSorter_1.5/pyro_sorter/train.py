"""Reproducible local training: python -m pyro_sorter.train PHOTOS LABELS OUTPUT."""
import argparse
import itertools
import json
from pathlib import Path
import numpy as np
from .catalog import Catalog
from .features import Vision, digest, compare
from .pair_model import vector, predict
from .smart import segment_smart


def fit(x, y):
    mean=x.mean(0);scale=x.std(0)+1e-6
    x=np.c_[np.ones(len(x)),(x-mean)/scale];w=np.zeros(x.shape[1])
    sample_weights=np.where(y==1,.5/max(y.mean(),1e-6),.5/max(1-y.mean(),1e-6))
    for _ in range(2500):
        prediction=1/(1+np.exp(-np.clip(x@w,-30,30)))
        gradient=x.T@((prediction-y)*sample_weights)/len(x)
        gradient[1:]+=.025*w[1:];w-=.08*gradient
    return dict(mean=mean.tolist(),scale=scale.tolist(),weights=w.tolist(),
                features=['color','region_color','center_color','local','detail'])


def partition(photos,model,lookup):
    return segment_smart(photos,model=model)[0]


def errors(photos,groups,held=None):
    membership={pid:k for k,g in enumerate(groups) for pid in g['photo_ids']}
    fp=fn=0
    for i,a in enumerate(photos):
        for b in photos[:i]:
            if held is not None and a['label']!=held and b['label']!=held: continue
            truth=a['label']==b['label'];same=membership[a['id']]==membership[b['id']]
            fp+=int(same and not truth);fn+=int(not same and truth)
    return dict(false_merge_pairs=fp,false_split_pairs=fn,exact=fp==fn==0)


def calibrate(photos,model,lookup):
    best=None
    for cohesion,cost in itertools.product([.65,1,1.5,2,3],[.6,.9,1.15,1.5]):
        candidate={**model,'cohesion':cohesion,'group_cost':cost}
        groups=partition(photos,candidate,lookup);e=errors(photos,groups)
        rank=(e['false_merge_pairs']+e['false_split_pairs'],abs(cohesion-.65)+abs(cost-1.15))
        if best is None or rank<best[0]:best=(rank,candidate)
    return best[1]


def train(photos):
    lookup={};pairs=[]
    for i,a in enumerate(photos):
        for b in photos[:i]:
            signals=compare(b,a);lookup[tuple(sorted((a['id'],b['id'])))]=signals
            pairs.append((a,b,vector(signals),int(a['label']==b['label'])))
    def fitted(cohort):
        ids={p['id'] for p in cohort};selected=[p for p in pairs if p[0]['id'] in ids and p[1]['id'] in ids]
        x=np.array([p[2] for p in selected]);y=np.array([p[3] for p in selected])
        return calibrate(cohort,fit(x,y),lookup)
    folds=[]
    for held in sorted({p['label'] for p in photos}):
        model=fitted([p for p in photos if p['label']!=held])
        folds.append(dict(held_out_product=held,**errors(photos,partition(photos,model,lookup),held)))
    model=fitted(photos);groups=partition(photos,model,lookup)
    return model,dict(images=len(photos),products=len({p['label'] for p in photos}),
        ocr=False,development_cross_validation=folds,training_fit=errors(photos,groups),
        groups=[g['photo_ids'] for g in groups],
        limitation='Small development set; not an independent final test. Pair counts across folds overlap.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('photos',type=Path);parser.add_argument('labels',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args()
    labels=json.loads(args.labels.read_text());args.output.mkdir(parents=True,exist_ok=True)
    if args.photos.resolve()==args.output.resolve() or args.photos.resolve() in args.output.resolve().parents:
        raise ValueError('Папка обучения должна быть вне исходных фото')
    vision=Vision(args.output/'cache',False);photos=[]
    for name,label in labels.items():
        if Path(name).name!=name:raise ValueError('В разметке нужны только имена файлов')
        p=args.photos/name;sha=digest(p)
        photos.append(dict(id=p.stem,filename=p.name,source=str(p.resolve()),sha256=sha,
            features=vision.extract(p,sha),match=Catalog().identify(''),text_tokens=[],label=label))
    if len({p['label'] for p in photos})<3:raise ValueError('Нужно минимум три товара')
    model,report=train(photos)
    (args.output/'pair_model.json').write_text(json.dumps(model,indent=2))
    (args.output/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
