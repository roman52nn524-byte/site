"""Build a focused queue from current vs nearby group support."""
from pathlib import Path
from .features import Vision, digest
from .smart import learned_affinity


def build_queue(project,home,model,progress=lambda *_:None,cancel=lambda:False):
    photos={p['id']:p for p in project['photos']};order={p['id']:i for i,p in enumerate(project['photos'])}
    groups=sorted((g for g in project['groups'] if g['status']!='rejected'),key=lambda g:min(order[i] for i in g['photo_ids']))
    vision=Vision(Path(home)/'cache',False);features={};questions=[];failures={}
    def row(pid):
        if pid in failures:return None
        if pid not in features:
            p=photos[pid]
            try:
                if p.get('error') or digest(p['source'])!=p['sha256']:raise ValueError('Файл повреждён или изменён')
                features[pid]={**p,'features':vision.extract(p['source'],p['sha256'])}
            except (OSError,ValueError) as e:
                failures[pid]=str(e);return None
        return features[pid]
    def check():
        if cancel():raise InterruptedError('Поиск спорных мест отменён.')
    def support(photo,group):
        ids=[pid for pid in group['photo_ids'] if pid!=photo['id']]
        # Up to six spread-out representatives of a large group.
        if len(ids)>6:ids=[ids[round(i*(len(ids)-1)/5)] for i in range(6)]
        values=[]
        for pid in ids:
            check();other=row(pid)
            if other:values.append(learned_affinity(photo,other,model))
        values.sort(reverse=True)
        return sum(values[:2])/max(1,len(values[:2]))
    done=0
    for index,group in enumerate(groups):
        for pid in group['photo_ids']:
            check();done+=1;progress(done,len(photos),'Ищем спорные фотографии')
            if pid in project.get('review_votes',{}):continue
            photo=row(pid)
            if photo is None:continue
            own=support(photo,group);alternatives=[]
            for target in groups[max(0,index-1):index+2]:
                if target['id']==group['id']:continue
                target_photo=photos[target['photo_ids'][0]]
                if Path(target_photo['source']).parent!=Path(photo['source']).parent:continue
                keys={photos[x]['match']['key'] for x in target['photo_ids'] if photos[x]['match']['strong']}
                if photo['match']['strong'] and keys and photo['match']['key'] not in keys:continue
                alternatives.append((support(photo,target),target))
            alternatives.sort(key=lambda item:item[0],reverse=True)
            if not alternatives:continue
            best,target=alternatives[0]
            if own<.65 or best>=own-.18:
                questions.append(dict(photo_id=pid,current=group['id'],alternative=target['id'],
                    own_score=own,alternative_score=best,priority=best-own,
                    reason='Сходство с двумя группами близкое' if abs(best-own)<.18 else 'Слабое сходство внутри текущей группы'))
    questions.sort(key=lambda q:q['priority'],reverse=True)
    return dict(revision=project['revision'],questions=questions,failures=failures)
