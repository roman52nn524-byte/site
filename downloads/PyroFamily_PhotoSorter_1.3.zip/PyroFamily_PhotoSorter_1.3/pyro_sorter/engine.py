import csv
import json
import logging
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from .catalog import Catalog
from .features import Vision, digest, compare

EXTENSIONS = {'.jpg', '.jpeg', '.png', '.heic', '.heif', '.webp', '.tif', '.tiff'}


def natural(path):
    return (str(path.parent).casefold(), tuple((0, int(t)) if t.isdigit() else (1, t.lower()) for t in re.split(r'(\d+)', path.name)))


def time_gap(a, b):
    x, y = a['features'].get('timestamp'), b['features'].get('timestamp')
    return abs(x-y) if x is not None and y is not None else None


def edge(a, b, anchor=None):
    if a.get('error') or b.get('error'):
        return False, .98, 'Повреждённый или недоступный файл', {}
    ka, kb = a['match'], b['match']
    if ka.get('conflict') or kb.get('conflict'):
        return False, .9, 'Несколько артикулов на одном кадре', {}
    group_key = anchor or (ka['key'] if ka['strong'] else '')
    if group_key and kb['strong'] and kb['key'] != group_key:
        return False, .98, 'Разные достоверные артикулы', {}
    if Path(a['source']).parent != Path(b['source']).parent:
        return False, .85, 'Разные исходные папки', {}
    gap = time_gap(a, b)
    if gap is not None and gap > 3600:
        return False, .85, 'Перерыв съёмки больше часа', {'seconds': gap}
    if a['sha256'] == b['sha256']:
        return True, .99, 'Точные дубликаты содержимого', {}
    same = group_key and kb['strong'] and kb['key'] == group_key
    if same:
        return True, .94, 'Совпадение достоверного артикула', {}
    sim = compare(a, b)
    wa, wb = set(a.get('text_tokens', [])), set(b.get('text_tokens', []))
    overlap = len(wa & wb) / max(1, len(wa | wb))
    sim['text'] = overlap
    if gap is not None and gap > 180:
        return False, .8, 'Перерыв съёмки; нет совпадения артикула', sim
    if sim['local'] >= .18 and (sim['color'] >= .48 or overlap >= .15):
        return True, .86, 'Геометрически согласованные локальные признаки', sim
    if sim['embedding'] is not None and sim['embedding'] >= .88 and (sim['local'] >= .06 or overlap >= .2):
        return True, .82, 'Embedding подтверждён текстом/локальными признаками', sim
    if sim['color'] >= .78 and overlap >= .3 and len(wa & wb) >= 2:
        return True, .73, 'Похожая упаковка и общий текст — проверить', sim
    return False, .55, 'Недостаточно независимых доказательств объединения', sim


def sequence_neighbor(a, b):
    """Consecutive camera filenames, including IMG_06-69 -> IMG_06-70."""
    a, b = Path(a['source']), Path(b['source'])
    if a.parent != b.parent:
        return False
    x = re.fullmatch(r'(.*?)(\d+)', a.stem.casefold())
    y = re.fullmatch(r'(.*?)(\d+)', b.stem.casefold())
    return bool(x and y and x[1] == y[1] and 0 < int(y[2])-int(x[2]) <= 3)


def automatic_edge(members, photo, signals, mode):
    previous = members[-1]
    if not sequence_neighbor(previous, photo):
        return False, .55, 'Нет близкой последовательности имён', signals
    # Compare with the first view too: adjacent color similarity alone can drift
    # through an entire folder containing different products.
    reference = compare(members[0], photo)
    threshold = .70 if mode == 'auto' else .52
    color = signals.get('color', 0)
    if color >= threshold and reference['color'] >= threshold - .10:
        return True, .64, 'Автогруппа: близкие номера файлов и похожие цвета упаковки', signals
    if signals.get('text', 0) >= .22 and color >= .40:
        return True, .68, 'Автогруппа: последовательность, общий текст и цвет', signals
    embedding = signals.get('embedding')
    if embedding is not None and embedding >= .84 and reference.get('embedding', 0) >= .80:
        return True, .70, 'Автогруппа: последовательность и сходство изображений', signals
    return False, .55, 'Смена внешнего вида товара', signals


def free_edge(members, photo, following):
    """Find support among all views, with one-frame lookahead for a reverse side."""
    previous = members[-1]
    if not sequence_neighbor(previous, photo):
        return False, .55, 'Разрыв последовательности', {}
    def support(candidate):
        best = (0, {})
        for member in members:
            sim = compare(member, candidate)
            common = set(member.get('text_tokens', [])) & set(candidate.get('text_tokens', []))
            # SIFT can match a printed element after scale/rotation changes.
            score = max(sim.get('detail',0)/.045 if sim.get('region_color',sim['color']) >= .35 else 0,
                        sim['local']/.08 if sim.get('region_color',sim['color']) >= .35 else 0,
                        sim.get('region_color',sim['color'])/.58,
                        min(len(common),3)/2 if sim['color'] >= .28 else 0)
            if score > best[0]:
                best = (score, sim)
        return best
    score, signals = support(photo)
    # Small series get more latitude; long series need stronger evidence.
    threshold = 1.0 if len(members) < 10 else 1.25
    if score >= threshold:
        return True, .62, 'Свободная серия: сходство с одним из ракурсов (цвет / детали / текст)', signals
    # A dissimilar reverse side may sit between two recognizable views.
    # Never bridge a SKU conflict, damaged frame, folder or time boundary.
    keys = {p['match']['key'] for p in members if p['match']['strong']}
    anchor = next(iter(keys), None)
    if following and len(members) < 10 and sequence_neighbor(photo, following):
        ok, confidence, _, _ = edge(photo, following, anchor)
        if ok or confidence < .8:
            next_score, _ = support(following)
            if next_score >= 1.15:
                return True, .48, 'Предполагаемый обратный ракурс между похожими кадрами — проверить', signals
    return False, .55, 'Недостаточно сходства с ракурсами серии', signals


def segment(photos, mode="strict"):
    if mode == "smart":
        from .smart import segment_smart
        return segment_smart(photos)
    if mode not in ("strict", "auto", "series", "free"):
        raise ValueError("Неизвестный режим группировки")
    groups, boundaries = [], []
    for i, photo in enumerate(photos):
        decision, confidence, reason, signals = False, .5, 'Первый кадр', {}
        if groups:
            group = groups[-1]
            members = [photos[j] for j in group['indices']]
            keys = {p['match']['key'] for p in members if p['match']['strong']}
            anchor = next(iter(keys), None)
            decision, confidence, reason, signals = edge(photos[i-1], photo, anchor)
            # Look back to a nearby supporting view, but never bypass a hard boundary.
            hard = confidence >= .8 and not decision
            if not decision and not hard:
                for support in members[-4:-1]:
                    ok, c, why, evidence = edge(support, photo, anchor)
                    if ok and c >= .82:
                        decision, confidence, reason, signals = ok, min(c, .82), 'Опорный ракурс: '+why, evidence
                        break
            if not decision and not hard and mode == 'free':
                decision, confidence, reason, signals = free_edge(members, photo, photos[i+1] if i+1 < len(photos) else None)
            if not decision and not hard and mode in ('auto', 'series'):
                decision, confidence, reason, signals = automatic_edge(members, photo, signals, mode)
            boundaries.append({'left': photos[i-1]['id'], 'right': photo['id'], 'split': not decision, 'confidence': confidence, 'reason': reason, 'signals': signals})
        if decision:
            groups[-1]['indices'].append(i)
            groups[-1]['confidence'] = min(groups[-1]['confidence'], confidence)
            groups[-1]['reasons'].append(reason)
        else:
            groups.append({'id': uuid.uuid4().hex[:12], 'indices': [i], 'confidence': .93 if photo['match']['strong'] else .45, 'reasons': [reason]})
    for group in groups:
        members = [photos[j] for j in group.pop('indices')]
        strong = next((p['match'] for p in members if p['match']['strong']), None)
        group.update(photo_ids=[p['id'] for p in members], name=strong['name'] if strong else '', sku=strong['sku'] if strong else '', status='pending', needs_review=True)
        if any(p.get('error') or p.get('ocr_error') or p['match'].get('conflict') for p in members):
            group['confidence'] = min(group['confidence'], .25)
        group['reasons'] = list(dict.fromkeys(group['reasons']))
    # Weak cut evidence makes both neighboring groups questionable, even if each has a SKU.
    for boundary in boundaries:
        if boundary['split'] and boundary['confidence'] < .75:
            for group in groups:
                if boundary['left'] in group['photo_ids'] or boundary['right'] in group['photo_ids']:
                    group['confidence'] = min(group['confidence'], .6)
                    group['reasons'].append('Неуверенная граница: нужна проверка соседней группы')
    return groups, boundaries


def analyze(source, catalog_path, cache, progress=lambda *_: None, cancel=lambda: False, ocr=True, weights=None, prior=None, mode="auto"):
    from .catalog import words
    source = Path(source).expanduser().resolve()
    if not source.is_dir():
        raise ValueError('Исходная папка не найдена.')
    paths = sorted((p for p in source.rglob('*') if p.is_file() and not p.is_symlink() and p.suffix.lower() in EXTENSIONS), key=natural)
    if not paths:
        raise ValueError('В папке нет поддерживаемых фотографий.')
    catalog = Catalog(Path(catalog_path).expanduser().resolve()) if catalog_path else Catalog()
    vision = Vision(cache, ocr, weights)
    previous = {}
    if prior:
        with open(prior, encoding='utf-8-sig', newline='') as f:
            for r in csv.DictReader(f):
                previous[str(Path(r.get('source', '')).expanduser().resolve())] = r.get('ocr_text', '')
    photos = []
    hashes = {}
    for i, p in enumerate(paths):
        if cancel():
            raise InterruptedError('Анализ отменён. Предыдущий проект сохранён.')
        progress(i, len(paths), p.name)
        row = {'id': uuid.uuid4().hex[:16], 'source': str(p), 'filename': p.name, 'error': None, 'duplicate_of': None}
        try:
            sha = digest(p)
            row['sha256'] = sha
            row['duplicate_of'] = hashes.get(sha)
            hashes.setdefault(sha, row['id'])
            row['features'] = vision.extract(p, sha)
            row['ocr_error'] = row['features'].get('ocr_error')
            lines = row['features']['ocr_lines']
            text = previous.get(str(p)) or '\n'.join(line['text'] for line in lines)
            confidence = .8 if previous.get(str(p)) else min((line['confidence'] for line in lines), default=0)
            row.update(ocr_text=text, match=catalog.identify(text, confidence), text_tokens=list(words(text)))
        except Exception as e:
            logging.exception('Ошибка фотографии %s', p.name)
            row.update(error=str(e), features={'timestamp': None}, ocr_text='', text_tokens=[], match=catalog.identify(''), sha256=row.get('sha256', ''))
        photos.append(row)
    # EXIF ordering is used only within folders where every frame has a timestamp.
    folders = {}
    for p in photos:
        folders.setdefault(str(Path(p['source']).parent), []).append(p)
    photos = []
    for folder in sorted(folders):
        batch = folders[folder]
        if all(p['features'].get('timestamp') is not None for p in batch):
            batch.sort(key=lambda p: (p['features']['timestamp'], natural(Path(p['source']))))
        photos.extend(batch)
    if mode == "smart":
        from .smart import segment_smart
        groups, boundaries = segment_smart(photos, progress, cancel)
    else:
        groups, boundaries = segment(photos, mode)
    for p in photos:
        p['thumbnail'] = p['features'].get('thumbnail')
        p['timestamp'] = p['features'].get('timestamp')
        del p['features']
    progress(len(paths), len(paths), 'Готово')
    return {'grouping_mode': mode, 'schema': 1, 'id': uuid.uuid4().hex, 'created': datetime.now(timezone.utc).isoformat(), 'source': str(source), 'catalog': str(catalog_path or ''), 'photos': photos, 'groups': groups, 'boundaries': boundaries, 'warnings': catalog.warnings + vision.warnings, 'revision': 0}
