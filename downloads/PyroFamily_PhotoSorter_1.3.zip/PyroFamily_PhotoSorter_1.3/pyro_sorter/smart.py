"""Sequence segmentation with a global minimum-cost partition, not a trained model."""
import uuid
from pathlib import Path
from .features import compare


def affinity(a, b):
    ka, kb = a['match'], b['match']
    if ka['strong'] and kb['strong']:
        return 1.0 if ka['key'] == kb['key'] else 0.0
    if a['sha256'] == b['sha256']:
        return 1.0
    sim = compare(a, b)
    color = sim.get('region_color', sim['color'])
    visual = max(0, min(1, (color-.20)/.65))
    # A shared detail needs some color support: background edges are not identity.
    if color >= .30:
        visual = max(visual, min(.95, sim.get('detail', 0)/.08),
                     min(.90, sim['local']/.16))
    common = set(a.get('text_tokens', [])) & set(b.get('text_tokens', []))
    if len(common) >= 2:
        visual = max(visual, .80)
    if sim.get('embedding') is not None:
        visual = max(visual, max(0, min(.95, (sim['embedding']-.65)/.25)))
    return visual


def segment_smart(photos, progress=lambda *_: None, cancel=lambda: False):
    from .engine import time_gap
    n = len(photos)
    if not n:
        return [], []
    blocked = [False]*n
    for i in range(1,n):
        a,b = photos[i-1],photos[i]
        blocked[i] = bool(a.get('error') or b.get('error') or
            a['match'].get('conflict') or b['match'].get('conflict') or
            Path(a['source']).parent != Path(b['source']).parent or
            (time_gap(a,b) is not None and time_gap(a,b)>3600))
    # Bound expensive visual comparisons to nearby shooting sessions.
    window = 40
    scores = {}
    def sim(i,j):
        if i == j: return 1.0
        key = (min(i,j),max(i,j))
        if key not in scores:
            scores[key] = affinity(photos[key[0]],photos[key[1]])
        return scores[key]
    costs = [0.0]+[float('inf')]*n
    previous = [0]*(n+1)
    confidence = {}
    for end in range(1,n+1):
        if cancel(): raise InterruptedError('Анализ отменён.')
        progress(end,n,'Сравниваем серии и выбираем границы товаров')
        keys=set(); best=[]; pair_loss=0.0
        for start in range(end-1,max(-1,end-window-1),-1):
            if start < end-1 and blocked[start+1]: break
            row=photos[start]
            if row['match']['strong']: keys.add(row['match']['key'])
            if len(keys)>1: break
            links=[sim(start,j) for j in range(start+1,end)]
            best=[max(old,link) for old,link in zip(best,links)]
            best.insert(0,max(links,default=0))
            pair_loss += sum(1-link for link in links)
            size=end-start
            # One weak reverse side is cheap inside a coherent series. A whole
            # second design increases pair disagreement and favors a new group.
            uncertain=sum(1-value for value in best)
            mean_loss=pair_loss/max(1,size*(size-1)/2)
            length_prior=.32*max(0,3-size)+.035*max(0,size-10)**2
            all_same=all(p['match']['strong'] for p in photos[start:end]) and len(keys)==1
            if all_same: length_prior=0
            cut=0 if start==0 or blocked[start] else .65*sim(start-1,start)
            cost=costs[start]+1.15+cut+.8*uncertain+.65*size*mean_loss+length_prior
            if cost<costs[end]:
                costs[end]=cost;previous[end]=start
                confidence[end]=max(.25,min(.90,1-uncertain/size))
    spans=[];end=n
    while end:
        start=previous[end];spans.append((start,end,confidence[end]));end=start
    spans.reverse()
    groups=[]; membership={}
    for start,end,conf in spans:
        members=photos[start:end]
        strong=next((p['match'] for p in members if p['match']['strong']),None)
        reasons=['Контекст серии: выбрано разбиение с учётом кадров до и после, общих деталей и длины серии']
        weak=[]
        for i in range(start,end):
            support=max((sim(i,j) for j in range(start,end) if i!=j),default=0)
            if support<.45: weak.append(photos[i].get('filename',Path(photos[i]['source']).name))
        if weak: reasons.append('Предположительно отнесены по последовательности: '+', '.join(weak))
        if any(p.get('error') or p.get('ocr_error') or p['match'].get('conflict') for p in members): conf=.25
        gid=uuid.uuid4().hex[:12]
        groups.append(dict(id=gid,photo_ids=[p['id'] for p in members],name=strong['name'] if strong else '',
            sku=strong['sku'] if strong else '',status='pending',needs_review=True,
            confidence=conf,reasons=reasons))
        for i in range(start,end): membership[i]=gid
    boundaries=[dict(left=photos[i-1]['id'],right=photos[i]['id'],split=membership[i-1]!=membership[i],
        confidence=.98 if blocked[i] else .55,reason='Граница выбрана по контексту серии',
        signals={} if blocked[i] else {'affinity':sim(i-1,i)}) for i in range(1,n)]
    return groups,boundaries
