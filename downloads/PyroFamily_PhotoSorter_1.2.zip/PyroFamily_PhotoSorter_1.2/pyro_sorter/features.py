import hashlib
import json
import subprocess
import sys
from pathlib import Path
from datetime import datetime
import cv2
import numpy as np
from PIL import Image, ImageOps
import pillow_heif
pillow_heif.register_heif_opener()
VERSION = 'features-1.2.0'


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


class Vision:
    def __init__(self, cache, enable_ocr=True, weights=None):
        self.cache = Path(cache)
        self.cache.mkdir(parents=True, exist_ok=True)
        self.enable_ocr = enable_ocr
        self.binary = None
        self.model = None
        self.model_key = 'none'
        self.warnings = []
        if enable_ocr:
            if sys.platform == 'darwin':
                source = Path(__file__).with_name('vision_ocr.swift')
                self.binary = self.cache / ('vision_' + digest(source)[:12])
                if not self.binary.exists():
                    try:
                        subprocess.run(['xcrun', 'swiftc', '-O', str(source), '-o', str(self.binary)], check=True, capture_output=True, timeout=180)
                    except (OSError, subprocess.SubprocessError) as e:
                        raise RuntimeError('Не удалось подготовить Apple Vision. Установите Command Line Tools: xcode-select --install. Для анализа без OCR снимите флажок OCR.') from e
            else:
                self.warnings.append('Apple Vision недоступен: не macOS. Используйте импорт OCR или ручную проверку.')
        if weights:
            if not Path(weights).is_file():
                raise ValueError('Не найден локальный файл весов OpenCLIP.')
            import torch
            import open_clip
            self.device = 'mps' if torch.backends.mps.is_available() else 'cpu'
            self.model, _, self.preprocess = open_clip.create_model_and_transforms('ViT-B-32', pretrained=str(weights), device=self.device)
            self.model.eval()
            self.model_key = digest(weights)
        self.cache_key = VERSION + '-' + self.model_key + ('-vision' if self.binary else '-noocr')

    def extract(self, path, sha):
        key = hashlib.sha256((sha + self.cache_key).encode()).hexdigest()
        target = self.cache / (key + '.json')
        if target.exists():
            try:
                data = json.loads(target.read_text())
                if data.get('version') == self.cache_key:
                    return data
            except (ValueError, OSError):
                pass
        with Image.open(path) as source:
            exif = source.getexif()
            try:
                exif.update(source.getexif().get_ifd(34665))
            except (KeyError, TypeError, ValueError):
                pass
            stamp = exif.get(36867) or exif.get(306)
            try:
                timestamp = datetime.strptime(str(stamp), '%Y:%m:%d %H:%M:%S').timestamp()
            except (ValueError, TypeError):
                timestamp = None
            image = ImageOps.exif_transpose(source).convert('RGB')
            image.thumbnail((1800, 1800))
            array = np.array(image)
        h, w = array.shape[:2]
        # Center-biased ROI, not a claimed learned package detector.
        roi = array[int(h*.12):int(h*.88), int(w*.12):int(w*.88)]
        hsv = cv2.cvtColor(roi, cv2.COLOR_RGB2HSV)
        hist = cv2.calcHist([hsv], [0, 1], None, [24, 16], [0, 180, 0, 256]).ravel()
        hist /= max(float(hist.sum()), 1)
        gray = cv2.cvtColor(roi, cv2.COLOR_RGB2GRAY)
        scale = min(1, 800 / max(gray.shape))
        gray = cv2.resize(gray, None, fx=scale, fy=scale)
        orb = cv2.ORB_create(nfeatures=600)
        points, descriptors = orb.detectAndCompute(gray, None)
        # Multiple crops reduce sensitivity to framing; saturated pixels reduce
        # the influence of a neutral table/background. No object detector claimed.
        regions = []
        for margin in (0, .20, .32):
            crop = array[int(h*margin):int(h*(1-margin)), int(w*margin):int(w*(1-margin))]
            chsv = cv2.cvtColor(crop, cv2.COLOR_RGB2HSV)
            mask = ((chsv[:,:,1] > 45) & (chsv[:,:,2] > 35)).astype(np.uint8)*255
            if np.count_nonzero(mask) < mask.size*.05:
                mask = None
            rh = cv2.calcHist([chsv], [0,1], mask, [24,16], [0,180,0,256]).ravel()
            rh /= max(float(rh.sum()), 1)
            regions.append(rh.tolist())
        broad = cv2.cvtColor(array, cv2.COLOR_RGB2GRAY)
        broad = cv2.resize(broad, None, fx=min(1,900/max(broad.shape)), fy=min(1,900/max(broad.shape)))
        sp, sd = cv2.SIFT_create(nfeatures=700).detectAndCompute(broad, None)
        embedding = None
        if self.model is not None:
            import torch
            with torch.inference_mode():
                vector = self.model.encode_image(self.preprocess(image).unsqueeze(0).to(self.device))
                vector = vector / vector.norm(dim=-1, keepdim=True)
                embedding = vector[0].cpu().numpy().tolist()
        lines, ocr_error = [], None
        if self.binary:
            prepared = self.cache / (key + '-ocr.jpg')
            image.save(prepared, quality=94)
            try:
                proc = subprocess.run([str(self.binary)], input=str(prepared)+'\n', text=True, capture_output=True, timeout=90, check=True)
                reply = json.loads(proc.stdout)
                lines, ocr_error = reply.get('lines', []), reply.get('error') or reply.get('warning')
            except (OSError, ValueError, subprocess.SubprocessError) as e:
                ocr_error = str(e)
            finally:
                prepared.unlink(missing_ok=True)
        thumbnail = self.cache / (key + '.jpg')
        preview = image.copy()
        preview.thumbnail((420, 320))
        preview.save(thumbnail, quality=85)
        data = {'regions': regions, 'sift': sd.tolist() if sd is not None else [], 'sift_points': [list(p.pt) for p in sp], 'version': self.cache_key, 'timestamp': timestamp, 'hist': hist.tolist(), 'descriptors': descriptors.tolist() if descriptors is not None else [], 'points': [list(p.pt) for p in points], 'embedding': embedding, 'ocr_lines': lines, 'ocr_error': ocr_error, 'thumbnail': str(thumbnail)}
        # Do not cache transient OCR failures as successful recognition.
        if not ocr_error:
            temp = target.with_suffix('.tmp')
            temp.write_text(json.dumps(data), encoding='utf-8')
            temp.replace(target)
        return data


def compare(a, b):
    key = b.get('id')
    if key is None:
        return _compare(a,b)
    cache = a['features'].setdefault('_comparisons', {})
    if key not in cache:
        cache[key] = _compare(a,b)
    return dict(cache[key])


def _compare(a, b):
    if a.get('error') or b.get('error'):
        return {'color': 0, 'local': 0, 'embedding': None}
    fa, fb = a['features'], b['features']
    color = float(np.minimum(fa['hist'], fb['hist']).sum())
    local = 0.0
    da, db = fa.get('descriptors'), fb.get('descriptors')
    if len(da or []) >= 8 and len(db or []) >= 8:
        pairs = cv2.BFMatcher(cv2.NORM_HAMMING).knnMatch(np.array(da, dtype=np.uint8), np.array(db, dtype=np.uint8), k=2)
        good = [m for pair in pairs if len(pair) == 2 for m, n in [pair] if m.distance < .7*n.distance]
        if len(good) >= 8:
            pa = np.float32([fa['points'][m.queryIdx] for m in good])
            pb = np.float32([fb['points'][m.trainIdx] for m in good])
            try:
                _, mask = cv2.findHomography(pa, pb, cv2.RANSAC, 4)
                local = float(mask.sum()) / max(1, min(len(da), len(db))) if mask is not None else 0
            except cv2.error:
                pass
    embedding = None
    if fa.get('embedding') is not None and fb.get('embedding') is not None:
        embedding = float(np.dot(fa['embedding'], fb['embedding']))
    region_color = max((float(np.minimum(x,y).sum()) for x in fa.get('regions',[]) for y in fb.get('regions',[])), default=color)
    detail = 0.0
    da, db = fa.get('sift', []), fb.get('sift', [])
    if len(da) >= 8 and len(db) >= 8:
        pairs = cv2.BFMatcher().knnMatch(np.array(da,np.float32),np.array(db,np.float32),k=2)
        good = [m for pair in pairs if len(pair)==2 for m,n in [pair] if m.distance < .72*n.distance]
        if len(good) >= 6:
            pa=np.float32([fa['sift_points'][m.queryIdx] for m in good])
            pb=np.float32([fb['sift_points'][m.trainIdx] for m in good])
            try:
                _,mask=cv2.findHomography(pa,pb,cv2.RANSAC,4)
                count=int(mask.sum()) if mask is not None else 0
                if count >= 6:
                    detail=count/max(20,min(len(da),len(db)))
            except cv2.error:
                pass
    return {'color': color, 'local': local, 'embedding': embedding, 'region_color': region_color, 'detail': detail}
